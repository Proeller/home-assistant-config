function t(t,e,i,s){var n,a=arguments.length,o=a<3?e:null===s?s=Object.getOwnPropertyDescriptor(e,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)o=Reflect.decorate(t,e,i,s);else for(var r=t.length-1;r>=0;r--)(n=t[r])&&(o=(a<3?n(o):a>3?n(e,i,o):n(e,i))||o);return a>3&&o&&Object.defineProperty(e,i,o),o}"function"==typeof SuppressedError&&SuppressedError;const e=globalThis,i=e.ShadowRoot&&(void 0===e.ShadyCSS||e.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,s=Symbol(),n=new WeakMap;let a=class{constructor(t,e,i){if(this._$cssResult$=!0,i!==s)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=t,this.t=e}get styleSheet(){let t=this.o;const e=this.t;if(i&&void 0===t){const i=void 0!==e&&1===e.length;i&&(t=n.get(e)),void 0===t&&((this.o=t=new CSSStyleSheet).replaceSync(this.cssText),i&&n.set(e,t))}return t}toString(){return this.cssText}};const o=(t,...e)=>{const i=1===t.length?t[0]:e.reduce((e,i,s)=>e+(t=>{if(!0===t._$cssResult$)return t.cssText;if("number"==typeof t)return t;throw Error("Value passed to 'css' function must be a 'css' function result: "+t+". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.")})(i)+t[s+1],t[0]);return new a(i,t,s)},r=i?t=>t:t=>t instanceof CSSStyleSheet?(t=>{let e="";for(const i of t.cssRules)e+=i.cssText;return(t=>new a("string"==typeof t?t:t+"",void 0,s))(e)})(t):t,{is:l,defineProperty:d,getOwnPropertyDescriptor:c,getOwnPropertyNames:h,getOwnPropertySymbols:p,getPrototypeOf:u}=Object,m=globalThis,g=m.trustedTypes,v=g?g.emptyScript:"",_=m.reactiveElementPolyfillSupport,f=(t,e)=>t,y={toAttribute(t,e){switch(e){case Boolean:t=t?v:null;break;case Object:case Array:t=null==t?t:JSON.stringify(t)}return t},fromAttribute(t,e){let i=t;switch(e){case Boolean:i=null!==t;break;case Number:i=null===t?null:Number(t);break;case Object:case Array:try{i=JSON.parse(t)}catch(t){i=null}}return i}},b=(t,e)=>!l(t,e),x={attribute:!0,type:String,converter:y,reflect:!1,useDefault:!1,hasChanged:b};Symbol.metadata??=Symbol("metadata"),m.litPropertyMetadata??=new WeakMap;let $=class extends HTMLElement{static addInitializer(t){this._$Ei(),(this.l??=[]).push(t)}static get observedAttributes(){return this.finalize(),this._$Eh&&[...this._$Eh.keys()]}static createProperty(t,e=x){if(e.state&&(e.attribute=!1),this._$Ei(),this.prototype.hasOwnProperty(t)&&((e=Object.create(e)).wrapped=!0),this.elementProperties.set(t,e),!e.noAccessor){const i=Symbol(),s=this.getPropertyDescriptor(t,i,e);void 0!==s&&d(this.prototype,t,s)}}static getPropertyDescriptor(t,e,i){const{get:s,set:n}=c(this.prototype,t)??{get(){return this[e]},set(t){this[e]=t}};return{get:s,set(e){const a=s?.call(this);n?.call(this,e),this.requestUpdate(t,a,i)},configurable:!0,enumerable:!0}}static getPropertyOptions(t){return this.elementProperties.get(t)??x}static _$Ei(){if(this.hasOwnProperty(f("elementProperties")))return;const t=u(this);t.finalize(),void 0!==t.l&&(this.l=[...t.l]),this.elementProperties=new Map(t.elementProperties)}static finalize(){if(this.hasOwnProperty(f("finalized")))return;if(this.finalized=!0,this._$Ei(),this.hasOwnProperty(f("properties"))){const t=this.properties,e=[...h(t),...p(t)];for(const i of e)this.createProperty(i,t[i])}const t=this[Symbol.metadata];if(null!==t){const e=litPropertyMetadata.get(t);if(void 0!==e)for(const[t,i]of e)this.elementProperties.set(t,i)}this._$Eh=new Map;for(const[t,e]of this.elementProperties){const i=this._$Eu(t,e);void 0!==i&&this._$Eh.set(i,t)}this.elementStyles=this.finalizeStyles(this.styles)}static finalizeStyles(t){const e=[];if(Array.isArray(t)){const i=new Set(t.flat(1/0).reverse());for(const t of i)e.unshift(r(t))}else void 0!==t&&e.push(r(t));return e}static _$Eu(t,e){const i=e.attribute;return!1===i?void 0:"string"==typeof i?i:"string"==typeof t?t.toLowerCase():void 0}constructor(){super(),this._$Ep=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this._$Em=null,this._$Ev()}_$Ev(){this._$ES=new Promise(t=>this.enableUpdating=t),this._$AL=new Map,this._$E_(),this.requestUpdate(),this.constructor.l?.forEach(t=>t(this))}addController(t){(this._$EO??=new Set).add(t),void 0!==this.renderRoot&&this.isConnected&&t.hostConnected?.()}removeController(t){this._$EO?.delete(t)}_$E_(){const t=new Map,e=this.constructor.elementProperties;for(const i of e.keys())this.hasOwnProperty(i)&&(t.set(i,this[i]),delete this[i]);t.size>0&&(this._$Ep=t)}createRenderRoot(){const t=this.shadowRoot??this.attachShadow(this.constructor.shadowRootOptions);return((t,s)=>{if(i)t.adoptedStyleSheets=s.map(t=>t instanceof CSSStyleSheet?t:t.styleSheet);else for(const i of s){const s=document.createElement("style"),n=e.litNonce;void 0!==n&&s.setAttribute("nonce",n),s.textContent=i.cssText,t.appendChild(s)}})(t,this.constructor.elementStyles),t}connectedCallback(){this.renderRoot??=this.createRenderRoot(),this.enableUpdating(!0),this._$EO?.forEach(t=>t.hostConnected?.())}enableUpdating(t){}disconnectedCallback(){this._$EO?.forEach(t=>t.hostDisconnected?.())}attributeChangedCallback(t,e,i){this._$AK(t,i)}_$ET(t,e){const i=this.constructor.elementProperties.get(t),s=this.constructor._$Eu(t,i);if(void 0!==s&&!0===i.reflect){const n=(void 0!==i.converter?.toAttribute?i.converter:y).toAttribute(e,i.type);this._$Em=t,null==n?this.removeAttribute(s):this.setAttribute(s,n),this._$Em=null}}_$AK(t,e){const i=this.constructor,s=i._$Eh.get(t);if(void 0!==s&&this._$Em!==s){const t=i.getPropertyOptions(s),n="function"==typeof t.converter?{fromAttribute:t.converter}:void 0!==t.converter?.fromAttribute?t.converter:y;this._$Em=s;const a=n.fromAttribute(e,t.type);this[s]=a??this._$Ej?.get(s)??a,this._$Em=null}}requestUpdate(t,e,i,s=!1,n){if(void 0!==t){const a=this.constructor;if(!1===s&&(n=this[t]),i??=a.getPropertyOptions(t),!((i.hasChanged??b)(n,e)||i.useDefault&&i.reflect&&n===this._$Ej?.get(t)&&!this.hasAttribute(a._$Eu(t,i))))return;this.C(t,e,i)}!1===this.isUpdatePending&&(this._$ES=this._$EP())}C(t,e,{useDefault:i,reflect:s,wrapped:n},a){i&&!(this._$Ej??=new Map).has(t)&&(this._$Ej.set(t,a??e??this[t]),!0!==n||void 0!==a)||(this._$AL.has(t)||(this.hasUpdated||i||(e=void 0),this._$AL.set(t,e)),!0===s&&this._$Em!==t&&(this._$Eq??=new Set).add(t))}async _$EP(){this.isUpdatePending=!0;try{await this._$ES}catch(t){Promise.reject(t)}const t=this.scheduleUpdate();return null!=t&&await t,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){if(!this.isUpdatePending)return;if(!this.hasUpdated){if(this.renderRoot??=this.createRenderRoot(),this._$Ep){for(const[t,e]of this._$Ep)this[t]=e;this._$Ep=void 0}const t=this.constructor.elementProperties;if(t.size>0)for(const[e,i]of t){const{wrapped:t}=i,s=this[e];!0!==t||this._$AL.has(e)||void 0===s||this.C(e,void 0,i,s)}}let t=!1;const e=this._$AL;try{t=this.shouldUpdate(e),t?(this.willUpdate(e),this._$EO?.forEach(t=>t.hostUpdate?.()),this.update(e)):this._$EM()}catch(e){throw t=!1,this._$EM(),e}t&&this._$AE(e)}willUpdate(t){}_$AE(t){this._$EO?.forEach(t=>t.hostUpdated?.()),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(t)),this.updated(t)}_$EM(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$ES}shouldUpdate(t){return!0}update(t){this._$Eq&&=this._$Eq.forEach(t=>this._$ET(t,this[t])),this._$EM()}updated(t){}firstUpdated(t){}};$.elementStyles=[],$.shadowRootOptions={mode:"open"},$[f("elementProperties")]=new Map,$[f("finalized")]=new Map,_?.({ReactiveElement:$}),(m.reactiveElementVersions??=[]).push("2.1.2");const w=globalThis,k=t=>t,E=w.trustedTypes,S=E?E.createPolicy("lit-html",{createHTML:t=>t}):void 0,A="$lit$",T=`lit$${Math.random().toFixed(9).slice(2)}$`,D="?"+T,M=`<${D}>`,C=document,L=()=>C.createComment(""),O=t=>null===t||"object"!=typeof t&&"function"!=typeof t,I=Array.isArray,N="[ \t\n\f\r]",P=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,H=/-->/g,B=/>/g,z=RegExp(`>|${N}(?:([^\\s"'>=/]+)(${N}*=${N}*(?:[^ \t\n\f\r"'\`<>=]|("|')|))|$)`,"g"),U=/'/g,R=/"/g,W=/^(?:script|style|textarea|title)$/i,V=(t,...e)=>({_$litType$:1,strings:t,values:e}),F=Symbol.for("lit-noChange"),j=Symbol.for("lit-nothing"),Y=new WeakMap,Z=C.createTreeWalker(C,129);function q(t,e){if(!I(t)||!t.hasOwnProperty("raw"))throw Error("invalid template strings array");return void 0!==S?S.createHTML(e):e}class J{constructor({strings:t,_$litType$:e},i){let s;this.parts=[];let n=0,a=0;const o=t.length-1,r=this.parts,[l,d]=((t,e)=>{const i=t.length-1,s=[];let n,a=2===e?"<svg>":3===e?"<math>":"",o=P;for(let e=0;e<i;e++){const i=t[e];let r,l,d=-1,c=0;for(;c<i.length&&(o.lastIndex=c,l=o.exec(i),null!==l);)c=o.lastIndex,o===P?"!--"===l[1]?o=H:void 0!==l[1]?o=B:void 0!==l[2]?(W.test(l[2])&&(n=RegExp("</"+l[2],"g")),o=z):void 0!==l[3]&&(o=z):o===z?">"===l[0]?(o=n??P,d=-1):void 0===l[1]?d=-2:(d=o.lastIndex-l[2].length,r=l[1],o=void 0===l[3]?z:'"'===l[3]?R:U):o===R||o===U?o=z:o===H||o===B?o=P:(o=z,n=void 0);const h=o===z&&t[e+1].startsWith("/>")?" ":"";a+=o===P?i+M:d>=0?(s.push(r),i.slice(0,d)+A+i.slice(d)+T+h):i+T+(-2===d?e:h)}return[q(t,a+(t[i]||"<?>")+(2===e?"</svg>":3===e?"</math>":"")),s]})(t,e);if(this.el=J.createElement(l,i),Z.currentNode=this.el.content,2===e||3===e){const t=this.el.content.firstChild;t.replaceWith(...t.childNodes)}for(;null!==(s=Z.nextNode())&&r.length<o;){if(1===s.nodeType){if(s.hasAttributes())for(const t of s.getAttributeNames())if(t.endsWith(A)){const e=d[a++],i=s.getAttribute(t).split(T),o=/([.?@])?(.*)/.exec(e);r.push({type:1,index:n,name:o[2],strings:i,ctor:"."===o[1]?tt:"?"===o[1]?et:"@"===o[1]?it:Q}),s.removeAttribute(t)}else t.startsWith(T)&&(r.push({type:6,index:n}),s.removeAttribute(t));if(W.test(s.tagName)){const t=s.textContent.split(T),e=t.length-1;if(e>0){s.textContent=E?E.emptyScript:"";for(let i=0;i<e;i++)s.append(t[i],L()),Z.nextNode(),r.push({type:2,index:++n});s.append(t[e],L())}}}else if(8===s.nodeType)if(s.data===D)r.push({type:2,index:n});else{let t=-1;for(;-1!==(t=s.data.indexOf(T,t+1));)r.push({type:7,index:n}),t+=T.length-1}n++}}static createElement(t,e){const i=C.createElement("template");return i.innerHTML=t,i}}function X(t,e,i=t,s){if(e===F)return e;let n=void 0!==s?i._$Co?.[s]:i._$Cl;const a=O(e)?void 0:e._$litDirective$;return n?.constructor!==a&&(n?._$AO?.(!1),void 0===a?n=void 0:(n=new a(t),n._$AT(t,i,s)),void 0!==s?(i._$Co??=[])[s]=n:i._$Cl=n),void 0!==n&&(e=X(t,n._$AS(t,e.values),n,s)),e}class G{constructor(t,e){this._$AV=[],this._$AN=void 0,this._$AD=t,this._$AM=e}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(t){const{el:{content:e},parts:i}=this._$AD,s=(t?.creationScope??C).importNode(e,!0);Z.currentNode=s;let n=Z.nextNode(),a=0,o=0,r=i[0];for(;void 0!==r;){if(a===r.index){let e;2===r.type?e=new K(n,n.nextSibling,this,t):1===r.type?e=new r.ctor(n,r.name,r.strings,this,t):6===r.type&&(e=new st(n,this,t)),this._$AV.push(e),r=i[++o]}a!==r?.index&&(n=Z.nextNode(),a++)}return Z.currentNode=C,s}p(t){let e=0;for(const i of this._$AV)void 0!==i&&(void 0!==i.strings?(i._$AI(t,i,e),e+=i.strings.length-2):i._$AI(t[e])),e++}}class K{get _$AU(){return this._$AM?._$AU??this._$Cv}constructor(t,e,i,s){this.type=2,this._$AH=j,this._$AN=void 0,this._$AA=t,this._$AB=e,this._$AM=i,this.options=s,this._$Cv=s?.isConnected??!0}get parentNode(){let t=this._$AA.parentNode;const e=this._$AM;return void 0!==e&&11===t?.nodeType&&(t=e.parentNode),t}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(t,e=this){t=X(this,t,e),O(t)?t===j||null==t||""===t?(this._$AH!==j&&this._$AR(),this._$AH=j):t!==this._$AH&&t!==F&&this._(t):void 0!==t._$litType$?this.$(t):void 0!==t.nodeType?this.T(t):(t=>I(t)||"function"==typeof t?.[Symbol.iterator])(t)?this.k(t):this._(t)}O(t){return this._$AA.parentNode.insertBefore(t,this._$AB)}T(t){this._$AH!==t&&(this._$AR(),this._$AH=this.O(t))}_(t){this._$AH!==j&&O(this._$AH)?this._$AA.nextSibling.data=t:this.T(C.createTextNode(t)),this._$AH=t}$(t){const{values:e,_$litType$:i}=t,s="number"==typeof i?this._$AC(t):(void 0===i.el&&(i.el=J.createElement(q(i.h,i.h[0]),this.options)),i);if(this._$AH?._$AD===s)this._$AH.p(e);else{const t=new G(s,this),i=t.u(this.options);t.p(e),this.T(i),this._$AH=t}}_$AC(t){let e=Y.get(t.strings);return void 0===e&&Y.set(t.strings,e=new J(t)),e}k(t){I(this._$AH)||(this._$AH=[],this._$AR());const e=this._$AH;let i,s=0;for(const n of t)s===e.length?e.push(i=new K(this.O(L()),this.O(L()),this,this.options)):i=e[s],i._$AI(n),s++;s<e.length&&(this._$AR(i&&i._$AB.nextSibling,s),e.length=s)}_$AR(t=this._$AA.nextSibling,e){for(this._$AP?.(!1,!0,e);t!==this._$AB;){const e=k(t).nextSibling;k(t).remove(),t=e}}setConnected(t){void 0===this._$AM&&(this._$Cv=t,this._$AP?.(t))}}class Q{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(t,e,i,s,n){this.type=1,this._$AH=j,this._$AN=void 0,this.element=t,this.name=e,this._$AM=s,this.options=n,i.length>2||""!==i[0]||""!==i[1]?(this._$AH=Array(i.length-1).fill(new String),this.strings=i):this._$AH=j}_$AI(t,e=this,i,s){const n=this.strings;let a=!1;if(void 0===n)t=X(this,t,e,0),a=!O(t)||t!==this._$AH&&t!==F,a&&(this._$AH=t);else{const s=t;let o,r;for(t=n[0],o=0;o<n.length-1;o++)r=X(this,s[i+o],e,o),r===F&&(r=this._$AH[o]),a||=!O(r)||r!==this._$AH[o],r===j?t=j:t!==j&&(t+=(r??"")+n[o+1]),this._$AH[o]=r}a&&!s&&this.j(t)}j(t){t===j?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,t??"")}}class tt extends Q{constructor(){super(...arguments),this.type=3}j(t){this.element[this.name]=t===j?void 0:t}}class et extends Q{constructor(){super(...arguments),this.type=4}j(t){this.element.toggleAttribute(this.name,!!t&&t!==j)}}class it extends Q{constructor(t,e,i,s,n){super(t,e,i,s,n),this.type=5}_$AI(t,e=this){if((t=X(this,t,e,0)??j)===F)return;const i=this._$AH,s=t===j&&i!==j||t.capture!==i.capture||t.once!==i.once||t.passive!==i.passive,n=t!==j&&(i===j||s);s&&this.element.removeEventListener(this.name,this,i),n&&this.element.addEventListener(this.name,this,t),this._$AH=t}handleEvent(t){"function"==typeof this._$AH?this._$AH.call(this.options?.host??this.element,t):this._$AH.handleEvent(t)}}class st{constructor(t,e,i){this.element=t,this.type=6,this._$AN=void 0,this._$AM=e,this.options=i}get _$AU(){return this._$AM._$AU}_$AI(t){X(this,t)}}const nt={I:K},at=w.litHtmlPolyfillSupport;at?.(J,K),(w.litHtmlVersions??=[]).push("3.3.2");const ot=globalThis;let rt=class extends ${constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){const t=super.createRenderRoot();return this.renderOptions.renderBefore??=t.firstChild,t}update(t){const e=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(t),this._$Do=((t,e,i)=>{const s=i?.renderBefore??e;let n=s._$litPart$;if(void 0===n){const t=i?.renderBefore??null;s._$litPart$=n=new K(e.insertBefore(L(),t),t,void 0,i??{})}return n._$AI(t),n})(e,this.renderRoot,this.renderOptions)}connectedCallback(){super.connectedCallback(),this._$Do?.setConnected(!0)}disconnectedCallback(){super.disconnectedCallback(),this._$Do?.setConnected(!1)}render(){return F}};rt._$litElement$=!0,rt.finalized=!0,ot.litElementHydrateSupport?.({LitElement:rt});const lt=ot.litElementPolyfillSupport;lt?.({LitElement:rt}),(ot.litElementVersions??=[]).push("4.2.2");const dt={attribute:!0,type:String,converter:y,reflect:!1,hasChanged:b},ct=(t=dt,e,i)=>{const{kind:s,metadata:n}=i;let a=globalThis.litPropertyMetadata.get(n);if(void 0===a&&globalThis.litPropertyMetadata.set(n,a=new Map),"setter"===s&&((t=Object.create(t)).wrapped=!0),a.set(i.name,t),"accessor"===s){const{name:s}=i;return{set(i){const n=e.get.call(this);e.set.call(this,i),this.requestUpdate(s,n,t,!0,i)},init(e){return void 0!==e&&this.C(s,void 0,t,e),e}}}if("setter"===s){const{name:s}=i;return function(i){const n=this[s];e.call(this,i),this.requestUpdate(s,n,t,!0,i)}}throw Error("Unsupported decorator location: "+s)};function ht(t){return(e,i)=>"object"==typeof i?ct(t,e,i):((t,e,i)=>{const s=e.hasOwnProperty(i);return e.constructor.createProperty(i,t),s?Object.getOwnPropertyDescriptor(e,i):void 0})(t,e,i)}function pt(t){return ht({...t,state:!0,attribute:!1})}const ut=["MONDAY","TUESDAY","WEDNESDAY","THURSDAY","FRIDAY","SATURDAY","SUNDAY"],mt=["fixed_time","astro","fixed_if_before_astro","astro_if_before_fixed","fixed_if_after_astro","astro_if_after_fixed","earliest","latest"],gt={switch:{levelType:"binary",hasLevel2:!1,hasDuration:!0,hasRampTime:!1},light:{levelType:"percentage",hasLevel2:!1,hasDuration:!0,hasRampTime:!0},cover:{levelType:"percentage",hasLevel2:!0,hasDuration:!1,hasRampTime:!1},valve:{levelType:"percentage",hasLevel2:!1,hasDuration:!0,hasRampTime:!1}},vt=["ms","s","min","h"];function _t(t){const[e,i]=t.split(":").map(Number);return 60*e+i}function ft(t){const e=t%60;return`${Math.floor(t/60).toString().padStart(2,"0")}:${e.toString().padStart(2,"0")}`}function yt(t,e="24"){if("24"===e)return t;const[i,s]=t.split(":");let n=parseInt(i,10);if(24===n)return"12:00 AM";const a=n>=12?"PM":"AM";return 0===n?n=12:n>12&&(n-=12),`${n}:${s||"00"} ${a}`}function bt(t){return t<10?"#2b9af9":t<14?"#40c4ff":t<17?"#26c6da":t<19?"#66bb6a":t<21?"#9ccc65":t<23?"#ffb74d":t<25?"#ff8100":"#f4511e"}function xt(t){const{base_temperature:e,periods:i}=t,s=[],n=[...i].sort((t,e)=>_t(t.starttime)-_t(e.starttime));for(let t=0;t<n.length;t++){const e=n[t];s.push({startTime:e.starttime,startMinutes:_t(e.starttime),endTime:e.endtime,endMinutes:_t(e.endtime),temperature:e.temperature,slot:t+1})}return{blocks:s,baseTemperature:e}}function $t(t){if(0===t.length)return[];const e=[...t].sort((t,e)=>t.startMinutes-e.startMinutes),i=[];let s={...e[0]};for(let t=1;t<e.length;t++){const n=e[t];s.endMinutes===n.startMinutes&&s.temperature===n.temperature?s={...s,endTime:n.endTime,endMinutes:n.endMinutes}:(i.push(s),s={...n})}return i.push(s),i.map((t,e)=>({...t,slot:e+1}))}function wt(t,e){if(0===t.length)return[{startTime:"00:00",startMinutes:0,endTime:"24:00",endMinutes:1440,temperature:e,slot:1}];const i=[...t].sort((t,e)=>t.startMinutes-e.startMinutes),s=[];let n=0;for(const t of i)t.startMinutes>n&&s.push({startTime:ft(n),startMinutes:n,endTime:t.startTime,endMinutes:t.startMinutes,temperature:e,slot:s.length+1}),s.push({...t,slot:s.length+1}),n=t.endMinutes;return n<1440&&s.push({startTime:ft(n),startMinutes:n,endTime:"24:00",endMinutes:1440,temperature:e,slot:s.length+1}),$t(s)}function kt(t){return[...t].sort((t,e)=>t.startMinutes-e.startMinutes).map((t,e)=>({...t,slot:e+1}))}function Et(t){return Boolean(Array.isArray(t.weekdays)&&t.weekdays.length>0&&Array.isArray(t.target_channels)&&t.target_channels.length>0)}function St(t){return"fixed_time"!==t}const At=/^(\d+(?:\.\d+)?)\s*(ms|s|min|h)$/;function Tt(t){const e=t.trim().match(At);return e?{value:parseFloat(e[1]),unit:e[2]}:null}function Dt(t,e){return`${t}${e}`}function Mt(t){return At.test(t.trim())}function Ct(t){const e={weekdays:t.weekdays,time:t.time,target_channels:t.target_channels,level:t.level};return"fixed_time"!==t.condition&&(e.condition=t.condition),null!==t.astro_type&&(e.astro_type=t.astro_type),0!==t.astro_offset_minutes&&(e.astro_offset_minutes=t.astro_offset_minutes),null!==t.level_2&&(e.level_2=t.level_2),null!==t.duration&&(e.duration=t.duration),null!==t.ramp_time&&(e.ramp_time=t.ramp_time),e}function Lt(t){const e={};for(const[i,s]of Object.entries(t))e[i]=Ct(s);return e}function Ot(t){return"default"===t.schedule_type}const It=(t,e,i)=>{const s=new CustomEvent(e,{bubbles:!0,composed:!0,detail:i});t.dispatchEvent(s)};class Nt extends rt{constructor(){super(...arguments),this._computeLabel=t=>({entities:"Entities",name:"Card Name (optional)",editable:"Allow editing",schedule_domain:"Schedule Domain",hour_format:"Time format"}[t.name]||t.name)}_getScheduleEntityIds(){return this.hass?.states?Object.keys(this.hass.states).filter(t=>{if(!t.startsWith("sensor."))return!1;const e=this.hass?.states?.[t];return!!e&&Ot(e.attributes)}):[]}_buildEntitySchema(){return[{name:"entities",required:!0,selector:{entity:{multiple:!0,include_entities:this._getScheduleEntityIds()}}}]}static{this.OPTIONS_SCHEMA=[{name:"name",selector:{text:{}}},{name:"editable",selector:{boolean:{}},default:!0},{name:"schedule_domain",selector:{select:{options:[{value:"",label:"Auto (from entity)"},{value:"switch",label:"Switch"},{value:"light",label:"Light"},{value:"cover",label:"Cover"},{value:"valve",label:"Valve"}],mode:"dropdown"}},default:""},{name:"hour_format",selector:{select:{options:[{value:"24",label:"24h"},{value:"12",label:"12h (AM/PM)"}]}},default:"24"}]}setConfig(t){this._config=t}_getEntityIds(){return this._config?this._config.entities?this._config.entities:this._config.entity?[this._config.entity]:[]:[]}render(){if(!this.hass||!this._config)return j;const t={entities:this._getEntityIds()};return V`
      <ha-form
        .hass=${this.hass}
        .data=${t}
        .schema=${this._buildEntitySchema()}
        .computeLabel=${this._computeLabel}
        @value-changed=${this._entitiesChanged}
      ></ha-form>

      <ha-form
        .hass=${this.hass}
        .data=${{...this._config,schedule_domain:this._config.schedule_domain||""}}
        .schema=${Nt.OPTIONS_SCHEMA}
        .computeLabel=${this._computeLabel}
        @value-changed=${this._optionsChanged}
      ></ha-form>
    `}_entitiesChanged(t){t.stopPropagation();const e={...this._config,entities:t.detail.value?.entities||[]};delete e.entity,It(this,"config-changed",{config:e})}_optionsChanged(t){t.stopPropagation();const e=t.detail.value,i=e.schedule_domain,s={...this._config,...e,entities:this._config.entities};i||delete s.schedule_domain,It(this,"config-changed",{config:s})}static{this.styles=o`
    ha-form {
      display: block;
    }
  `}}function Pt(t){return e=>(customElements.get(t)||customElements.define(t,e),e)}t([ht({attribute:!1})],Nt.prototype,"hass",void 0),t([pt()],Nt.prototype,"_config",void 0),customElements.get("homematicip-local-schedule-card-editor")||customElements.define("homematicip-local-schedule-card-editor",Nt);let Ht=class{constructor(t){}get _$AU(){return this._$AM._$AU}_$AT(t,e,i){this._$Ct=t,this._$AM=e,this._$Ci=i}_$AS(t,e){return this.update(t,e)}update(t,e){return this.render(...e)}};const{I:Bt}=nt,zt=t=>t,Ut=()=>document.createComment(""),Rt=(t,e,i)=>{const s=t._$AA.parentNode,n=void 0===e?t._$AB:e._$AA;if(void 0===i){const e=s.insertBefore(Ut(),n),a=s.insertBefore(Ut(),n);i=new Bt(e,a,t,t.options)}else{const e=i._$AB.nextSibling,a=i._$AM,o=a!==t;if(o){let e;i._$AQ?.(t),i._$AM=t,void 0!==i._$AP&&(e=t._$AU)!==a._$AU&&i._$AP(e)}if(e!==n||o){let t=i._$AA;for(;t!==e;){const e=zt(t).nextSibling;zt(s).insertBefore(t,n),t=e}}}return i},Wt=(t,e,i=t)=>(t._$AI(e,i),t),Vt={},Ft=(t,e=Vt)=>t._$AH=e,jt=t=>{t._$AR(),t._$AA.remove()},Yt=(t,e,i)=>{const s=new Map;for(let n=e;n<=i;n++)s.set(t[n],n);return s},Zt=(t=>(...e)=>({_$litDirective$:t,values:e}))(class extends Ht{constructor(t){if(super(t),2!==t.type)throw Error("repeat() can only be used in text expressions")}dt(t,e,i){let s;void 0===i?i=e:void 0!==e&&(s=e);const n=[],a=[];let o=0;for(const e of t)n[o]=s?s(e,o):o,a[o]=i(e,o),o++;return{values:a,keys:n}}render(t,e,i){return this.dt(t,e,i).values}update(t,[e,i,s]){const n=(t=>t._$AH)(t),{values:a,keys:o}=this.dt(e,i,s);if(!Array.isArray(n))return this.ut=o,a;const r=this.ut??=[],l=[];let d,c,h=0,p=n.length-1,u=0,m=a.length-1;for(;h<=p&&u<=m;)if(null===n[h])h++;else if(null===n[p])p--;else if(r[h]===o[u])l[u]=Wt(n[h],a[u]),h++,u++;else if(r[p]===o[m])l[m]=Wt(n[p],a[m]),p--,m--;else if(r[h]===o[m])l[m]=Wt(n[h],a[m]),Rt(t,l[m+1],n[h]),h++,m--;else if(r[p]===o[u])l[u]=Wt(n[p],a[u]),Rt(t,n[h],n[p]),p--,u++;else if(void 0===d&&(d=Yt(o,u,m),c=Yt(r,h,p)),d.has(r[h]))if(d.has(r[p])){const e=c.get(o[u]),i=void 0!==e?n[e]:null;if(null===i){const e=Rt(t,n[h]);Wt(e,a[u]),l[u]=e}else l[u]=Wt(i,a[u]),Rt(t,n[h],i),n[e]=null;u++}else jt(n[p]),p--;else jt(n[h]),h++;for(;u<=m;){const e=Rt(t,l[m+1]);Wt(e,a[u]),l[u++]=e}for(;h<=p;){const t=n[h++];null!==t&&jt(t)}return this.ut=o,Ft(t,l),F}}),qt=o`
  :host {
    display: block;
  }

  .schedule-container {
    display: grid;
    grid-template-columns: auto repeat(7, minmax(0, 1fr));
    grid-template-rows: auto 1fr;
    gap: 8px;
    min-height: 400px;
    overflow: hidden;
    width: 100%;
    box-sizing: border-box;
  }

  .time-axis-header {
    /* Empty cell in row 1, col 1 - height matches weekday headers */
  }

  .time-axis-labels {
    position: relative;
    border-right: 2px solid var(--divider-color);
    min-width: 50px;
  }

  .time-label {
    position: absolute;
    right: 8px;
    transform: translateY(-50%);
    font-size: 11px;
    color: var(--secondary-text-color);
    white-space: nowrap;
  }

  .schedule-content {
    grid-column: 2 / -1;
    display: grid;
    grid-template-columns: repeat(7, minmax(0, 1fr));
    gap: 8px;
    position: relative;
    min-height: 300px;
  }

  .current-time-indicator {
    position: absolute;
    left: 0;
    right: 0;
    height: 2px;
    background-color: var(--error-color, #ff0000);
    border-top: 2px dashed var(--error-color, #ff0000);
    pointer-events: none;
    z-index: 10;
    transform: translateY(-50%);
    box-shadow: 0 0 4px rgba(255, 0, 0, 0.5);
    will-change: top;
  }

  .current-time-indicator::before {
    content: "";
    position: absolute;
    left: -6px;
    top: 50%;
    transform: translateY(-50%);
    width: 8px;
    height: 8px;
    background-color: var(--error-color, #ff0000);
    border-radius: 50%;
    box-shadow: 0 0 4px rgba(255, 0, 0, 0.7);
  }

  .weekday-header {
    padding: 4px 8px;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 4px;
    background-color: var(--primary-color);
    color: var(--text-primary-color);
    border: 1px solid var(--divider-color);
    border-radius: 4px;
    overflow: hidden;
    min-width: 0;
  }

  .weekday-label {
    font-weight: 500;
    font-size: 14px;
  }

  .weekday-actions {
    display: flex;
    gap: 2px;
    flex-shrink: 1;
    min-width: 0;
  }

  .weekday-actions ha-icon-button {
    --ha-icon-button-size: 28px;
    --ha-icon-button-icon-size: 16px;
    color: var(--text-primary-color, #fff);
    opacity: 0.7;
    flex-shrink: 0;
  }

  .weekday-actions ha-icon-button:hover {
    opacity: 1;
  }

  .copy-btn.active {
    opacity: 1;
    animation: pulse 1s ease-in-out;
    will-change: transform;
  }

  @keyframes pulse {
    0%,
    100% {
      transform: scale(1);
    }
    50% {
      transform: scale(1.1);
    }
  }

  ha-icon-button[disabled] {
    opacity: 0.5;
  }

  .time-blocks {
    flex: 1;
    display: flex;
    flex-direction: column;
    position: relative;
    overflow: visible;
    border: 1px solid var(--divider-color);
    border-radius: 4px;
  }

  .time-blocks.editable {
    cursor: pointer;
    will-change: transform, box-shadow;
  }

  .time-blocks.editable:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  }

  .time-blocks.editable:focus-visible {
    outline: 2px solid var(--primary-color, #03a9f4);
    outline-offset: 2px;
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  }

  .time-block {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 12px;
    font-weight: 500;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.5);
    transition: opacity 0.2s;
    cursor: pointer;
  }

  .time-block.base-temp-block {
    color: var(--secondary-text-color, #666);
    text-shadow: none;
    border-top: 1px dashed var(--divider-color, #ccc);
  }

  .time-block.base-temp-block:first-child {
    border-top: none;
  }

  .time-block:hover {
    opacity: 0.9;
  }

  .time-block:hover .time-block-tooltip {
    opacity: 1;
    visibility: visible;
  }

  .temperature {
    user-select: none;
    position: relative;
    z-index: 1;
  }

  /* Active block highlighting */
  .time-block.active {
    box-shadow:
      inset 0 0 0 3px rgba(255, 255, 255, 0.9),
      0 0 20px rgba(255, 255, 255, 0.6),
      0 0 30px rgba(255, 255, 255, 0.4);
    animation: pulse-glow 2s ease-in-out infinite;
    z-index: 10;
    will-change: box-shadow;
  }

  @keyframes pulse-glow {
    0%,
    100% {
      box-shadow:
        inset 0 0 0 3px rgba(255, 255, 255, 0.9),
        0 0 15px rgba(255, 255, 255, 0.5),
        0 0 25px rgba(255, 255, 255, 0.3);
    }
    50% {
      box-shadow:
        inset 0 0 0 3px rgba(255, 255, 255, 1),
        0 0 25px rgba(255, 255, 255, 0.8),
        0 0 40px rgba(255, 255, 255, 0.6);
    }
  }

  /* Tooltip styling */
  .time-block-tooltip {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background-color: rgba(0, 0, 0, 0.95);
    color: white;
    padding: 6px 10px;
    border-radius: 4px;
    font-size: 10px;
    white-space: nowrap;
    opacity: 0;
    visibility: hidden;
    transition:
      opacity 0.2s,
      visibility 0.2s;
    z-index: 1000;
    pointer-events: none;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.4);
    min-width: 80px;
  }

  .tooltip-time {
    font-weight: 500;
    margin-bottom: 2px;
    text-align: center;
    font-size: 10px;
    line-height: 1.2;
  }

  .tooltip-temp {
    text-align: center;
    font-size: 11px;
    font-weight: 600;
    line-height: 1.2;
  }

  .hint {
    margin-top: 12px;
    text-align: center;
    font-size: 12px;
    color: var(--secondary-text-color);
  }

  /* Mobile single-day view */
  .mobile-day-nav {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 4px 0;
    margin-bottom: 8px;
    background-color: var(--primary-color);
    color: var(--text-primary-color);
    border-radius: 4px;
  }

  .mobile-day-nav ha-icon-button {
    color: var(--text-primary-color, #fff);
    --ha-icon-button-size: 40px;
    --ha-icon-button-icon-size: 24px;
  }

  .mobile-day-name {
    font-size: 18px;
    font-weight: 500;
    min-width: 120px;
    text-align: center;
    user-select: none;
  }

  .mobile-schedule-container {
    display: grid;
    grid-template-columns: auto 1fr;
    gap: 8px;
    min-height: 400px;
    touch-action: pan-y;
  }

  .mobile-day-content {
    position: relative;
    display: flex;
    flex-direction: column;
    min-height: 400px;
  }

  .mobile-day-content .time-blocks {
    flex: 1;
  }

  .mobile-day-content .time-block {
    font-size: 14px;
    min-height: 24px;
  }

  .mobile-day-content .temperature {
    font-size: 14px;
  }

  .mobile-day-actions {
    display: flex;
    justify-content: center;
    gap: 16px;
    margin-top: 8px;
    padding: 4px 0;
  }

  .mobile-day-actions ha-icon-button {
    --ha-icon-button-size: 44px;
    --ha-icon-button-icon-size: 22px;
    color: var(--primary-color);
  }

  .mobile-day-actions .copy-btn.active {
    color: var(--accent-color, var(--primary-color));
    opacity: 1;
    animation: pulse 1s ease-in-out;
  }

  /* Mobile Optimization */
  @media (max-width: 768px) {
    .schedule-container {
      gap: 4px;
      min-height: 350px;
    }

    .time-axis-labels {
      min-width: 40px;
    }

    .time-label {
      font-size: 10px;
      right: 4px;
    }

    .schedule-content {
      gap: 4px;
    }

    .weekday-header {
      padding: 6px 4px;
    }

    .weekday-label {
      font-size: 12px;
    }

    .weekday-actions {
      gap: 0px;
    }

    .weekday-actions ha-icon-button {
      --ha-icon-button-size: 36px;
      --ha-icon-button-icon-size: 18px;
      min-width: 44px;
      min-height: 44px;
    }

    .temperature {
      font-size: 11px;
    }

    .time-block-tooltip {
      font-size: 11px;
      padding: 8px 12px;
    }

    .hint {
      font-size: 14px;
    }
  }

  /* Small mobile devices (portrait phones) */
  @media (max-width: 480px) {
    .schedule-container {
      gap: 2px;
      min-height: 300px;
    }

    .time-axis-labels {
      min-width: 35px;
    }

    .time-label {
      font-size: 9px;
      right: 2px;
    }

    .schedule-content {
      gap: 2px;
    }

    .weekday-header {
      padding: 4px 2px;
    }

    .weekday-label {
      font-size: 11px;
    }

    .weekday-actions ha-icon-button {
      --ha-icon-button-size: 32px;
      --ha-icon-button-icon-size: 16px;
      min-width: 44px;
      min-height: 44px;
    }

    .temperature {
      font-size: 10px;
    }
  }

  /* Touch-specific optimizations */
  @media (hover: none) and (pointer: coarse) {
    .time-blocks.editable:hover {
      transform: none;
      box-shadow: none;
    }

    .time-blocks.editable:active {
      transform: scale(0.98);
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    }

    .time-block:hover {
      opacity: 1;
    }

    .time-block:active {
      opacity: 0.85;
    }

    /* Show tooltip on tap instead of hover */
    .time-block:active .time-block-tooltip {
      opacity: 1;
      visibility: visible;
    }
  }
`;var Jt=function(t,e,i,s){var n,a=arguments.length,o=a<3?e:null===s?s=Object.getOwnPropertyDescriptor(e,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)o=Reflect.decorate(t,e,i,s);else for(var r=t.length-1;r>=0;r--)(n=t[r])&&(o=(a<3?n(o):a>3?n(e,i,o):n(e,i))||o);return a>3&&o&&Object.defineProperty(e,i,o),o};let Xt=class extends rt{constructor(){super(...arguments),this.editable=!1,this.showTemperature=!0,this.showGradient=!1,this.temperatureUnit="°C",this.hourFormat="24",this.editorOpen=!1,this._currentTimePercent=0,this._currentTimeMinutes=0,this._isMobile=!1,this._mobileSelectedDayIndex=0,this._mediaHandler=t=>{this._isMobile=t.matches},this._touchStartX=0,this._touchStartY=0}connectedCallback(){super.connectedCallback(),this._updateCurrentTime(),this._timeUpdateInterval=window.setInterval(()=>{this._updateCurrentTime()},6e4),this._mediaQuery=window.matchMedia("(max-width: 600px)"),this._isMobile=this._mediaQuery.matches,this._mediaQuery.addEventListener("change",this._mediaHandler),this._initMobileSelectedDay()}disconnectedCallback(){super.disconnectedCallback(),void 0!==this._timeUpdateInterval&&(clearInterval(this._timeUpdateInterval),this._timeUpdateInterval=void 0),this._mediaQuery&&(this._mediaQuery.removeEventListener("change",this._mediaHandler),this._mediaQuery=void 0)}willUpdate(t){super.willUpdate(t)}_updateCurrentTime(){const t=new Date,e=60*t.getHours()+t.getMinutes();this._currentTimePercent=e/1440*100,this._currentTimeMinutes=e;const i=t.getDay();this._currentWeekday=["SUNDAY","MONDAY","TUESDAY","WEDNESDAY","THURSDAY","FRIDAY","SATURDAY"][i]}_isBlockActive(t,e){return!(!this._currentWeekday||this._currentWeekday!==t)&&this._currentTimeMinutes>=e.startMinutes&&this._currentTimeMinutes<e.endMinutes}_getTimeLabels(){const t=[];for(let e=0;e<=24;e+=3){const i=`${e.toString().padStart(2,"0")}:00`;t.push({hour:e,label:yt(i,this.hourFormat),position:e/24*100})}return t}_formatTimeDisplay(t){return yt(t,this.hourFormat)}_getBaseTemperature(t){if(this.scheduleData){const e=this.scheduleData[t];if(e){const{baseTemperature:t}=xt(e);return t}}return 20}_getParsedBlocks(t){if(this.scheduleData){const e=this.scheduleData[t];if(!e)return[];const{blocks:i}=xt(e);return i}return[]}_getWeekdayLabel(t){return this.translations?.weekdayShortLabels[t]??t.slice(0,2)}_handleWeekdayClick(t){this.editable&&this.dispatchEvent(new CustomEvent("weekday-click",{detail:{weekday:t},bubbles:!0,composed:!0}))}_handleCopy(t,e){e.stopPropagation(),this.dispatchEvent(new CustomEvent("copy-schedule",{detail:{weekday:t},bubbles:!0,composed:!0}))}_handlePaste(t,e){e.stopPropagation(),this.dispatchEvent(new CustomEvent("paste-schedule",{detail:{weekday:t},bubbles:!0,composed:!0}))}_initMobileSelectedDay(){const t=(new Date).getDay();this._mobileSelectedDayIndex=0===t?6:t-1}_mobilePrevDay(){this._mobileSelectedDayIndex=(this._mobileSelectedDayIndex-1+ut.length)%ut.length}_mobileNextDay(){this._mobileSelectedDayIndex=(this._mobileSelectedDayIndex+1)%ut.length}_getWeekdayLongLabel(t){return this.translations?.weekdayLongLabels?.[t]??t.charAt(0)+t.slice(1).toLowerCase()}_handleTouchStart(t){this._touchStartX=t.touches[0].clientX,this._touchStartY=t.touches[0].clientY}_handleTouchEnd(t){const e=t.changedTouches[0].clientX-this._touchStartX,i=t.changedTouches[0].clientY-this._touchStartY;Math.abs(e)>50&&Math.abs(e)>1.5*Math.abs(i)&&(e<0?this._mobileNextDay():this._mobilePrevDay())}_renderTimeBlocks(t){const e=this._getParsedBlocks(t),i=this._getBaseTemperature(t),s=wt(e,i);return V`
      <div
        class="time-blocks ${this.editable?"editable":""}"
        tabindex=${this.editable?"0":"-1"}
        role=${this.editable?"button":"presentation"}
        aria-label=${this._getWeekdayLabel(t)}
        @click=${()=>this._handleWeekdayClick(t)}
        @keydown=${e=>{"Enter"!==e.key&&" "!==e.key||(e.preventDefault(),this._handleWeekdayClick(t))}}
      >
        ${Zt(s,t=>`${t.slot}-${t.startMinutes}-${this.currentProfile}`,(n,a)=>{const o=this._isBlockActive(t,n),r=n.temperature===i&&!e.some(t=>t.startMinutes===n.startMinutes&&t.endMinutes===n.endMinutes);let l;if(r)l="background-color: var(--secondary-background-color, #e0e0e0);";else if(this.showGradient){l=`background: ${function(t,e,i){const s=bt(t);return null===e&&null===i?s:null!==e&&null===i?`linear-gradient(to bottom, ${bt(e)}, ${s})`:null===e&&null!==i?`linear-gradient(to bottom, ${s}, ${bt(i)})`:`linear-gradient(to bottom, ${bt(e)}, ${s} 50%, ${bt(i)})`}(n.temperature,a>0?s[a-1].temperature:null,a<s.length-1?s[a+1].temperature:null)};`}else l=`background-color: ${bt(n.temperature)};`;return V`
              <div
                class="time-block ${o?"active":""} ${r?"base-temp-block":""}"
                style="
                    height: ${(n.endMinutes-n.startMinutes)/1440*100}%;
                    ${l}
                  "
              >
                ${this.showTemperature?V`<span class="temperature">${n.temperature.toFixed(1)}°</span>`:""}
                <div class="time-block-tooltip">
                  <div class="tooltip-time">
                    ${this._formatTimeDisplay(n.startTime)} -
                    ${this._formatTimeDisplay(n.endTime)}
                  </div>
                  <div class="tooltip-temp">
                    ${function(t,e="°C"){return`${t.toFixed(1)}${e}`}(n.temperature,this.temperatureUnit)}
                  </div>
                </div>
              </div>
            `})}
      </div>
    `}_renderMobile(){const t=ut[this._mobileSelectedDayIndex],e=this.copiedWeekday===t;return V`
      <div class="mobile-day-nav">
        <ha-icon-button
          .path=${"M15.41,16.58L10.83,12L15.41,7.41L14,6L8,12L14,18L15.41,16.58Z"}
          @click=${()=>this._mobilePrevDay()}
          .label=${this.translations?.previousDay??"Previous day"}
        ></ha-icon-button>
        <span class="mobile-day-name">${this._getWeekdayLongLabel(t)}</span>
        <ha-icon-button
          .path=${"M8.59,16.58L13.17,12L8.59,7.41L10,6L16,12L10,18L8.59,16.58Z"}
          @click=${()=>this._mobileNextDay()}
          .label=${this.translations?.nextDay??"Next day"}
        ></ha-icon-button>
      </div>

      <div
        class="mobile-schedule-container"
        @touchstart=${t=>this._handleTouchStart(t)}
        @touchend=${t=>this._handleTouchEnd(t)}
      >
        <div class="time-axis-labels">
          ${Zt(this._getTimeLabels(),t=>t.hour,t=>V`
              <div class="time-label" style="top: ${t.position}%">${t.label}</div>
            `)}
        </div>

        <div class="mobile-day-content">
          ${this._renderTimeBlocks(t)}

          <!-- Current time indicator line (hidden when editor is open) -->
          ${this.editorOpen||this._currentWeekday!==t?"":V`<div
                class="current-time-indicator"
                style="top: ${this._currentTimePercent}%"
              ></div>`}
        </div>
      </div>

      ${this.editable?V`
            <div class="mobile-day-actions">
              <ha-icon-button
                class="copy-btn ${e?"active":""}"
                .path=${"M19,21H8V7H19M19,5H8A2,2 0 0,0 6,7V21A2,2 0 0,0 8,23H19A2,2 0 0,0 21,21V7A2,2 0 0,0 19,5M16,1H4A2,2 0 0,0 2,3V17H4V3H16V1Z"}
                @click=${e=>this._handleCopy(t,e)}
                .label=${this.translations?.copySchedule??""}
              ></ha-icon-button>
              <ha-icon-button
                class="paste-btn"
                .path=${"M19,20H5V4H7V7H17V4H19M12,2A1,1 0 0,1 13,3A1,1 0 0,1 12,4A1,1 0 0,1 11,3A1,1 0 0,1 12,2M19,2H14.82C14.4,0.84 13.3,0 12,0C10.7,0 9.6,0.84 9.18,2H5A2,2 0 0,0 3,4V20A2,2 0 0,0 5,22H19A2,2 0 0,0 21,20V4A2,2 0 0,0 19,2Z"}
                @click=${e=>this._handlePaste(t,e)}
                .label=${this.translations?.pasteSchedule??""}
                .disabled=${!this.copiedWeekday}
              ></ha-icon-button>
            </div>
          `:""}
      ${this.editable?V`<div class="hint">${this.translations?.clickToEdit??""}</div>`:""}
    `}_renderDesktop(){return V`
      <div class="schedule-container">
        <!-- Empty cell for time-axis header alignment -->
        <div class="time-axis-header"></div>

        <!-- Weekday headers -->
        ${Zt(ut,t=>`header-${t}`,t=>{const e=this.copiedWeekday===t;return V`
              <div class="weekday-header">
                <div class="weekday-label">${this._getWeekdayLabel(t)}</div>
                ${this.editable?V`
                      <div class="weekday-actions">
                        <ha-icon-button
                          class="copy-btn ${e?"active":""}"
                          .path=${"M19,21H8V7H19M19,5H8A2,2 0 0,0 6,7V21A2,2 0 0,0 8,23H19A2,2 0 0,0 21,21V7A2,2 0 0,0 19,5M16,1H4A2,2 0 0,0 2,3V17H4V3H16V1Z"}
                          @click=${e=>this._handleCopy(t,e)}
                          .label=${this.translations?.copySchedule??""}
                        ></ha-icon-button>
                        <ha-icon-button
                          class="paste-btn"
                          .path=${"M19,20H5V4H7V7H17V4H19M12,2A1,1 0 0,1 13,3A1,1 0 0,1 12,4A1,1 0 0,1 11,3A1,1 0 0,1 12,2M19,2H14.82C14.4,0.84 13.3,0 12,0C10.7,0 9.6,0.84 9.18,2H5A2,2 0 0,0 3,4V20A2,2 0 0,0 5,22H19A2,2 0 0,0 21,20V4A2,2 0 0,0 19,2Z"}
                          @click=${e=>this._handlePaste(t,e)}
                          .label=${this.translations?.pasteSchedule??""}
                          .disabled=${!this.copiedWeekday}
                        ></ha-icon-button>
                      </div>
                    `:""}
              </div>
            `})}

        <!-- Time axis labels -->
        <div class="time-axis-labels">
          ${Zt(this._getTimeLabels(),t=>t.hour,t=>V`
              <div class="time-label" style="top: ${t.position}%">${t.label}</div>
            `)}
        </div>

        <!-- Time blocks content wrapper (for correct indicator positioning) -->
        <div class="schedule-content">
          ${Zt(ut,t=>`${t}-${this.currentProfile}-${this.scheduleDataHash}`,t=>this._renderTimeBlocks(t))}

          <!-- Current time indicator line (hidden when editor is open) -->
          ${this.editorOpen?"":V`<div
                class="current-time-indicator"
                style="top: ${this._currentTimePercent}%"
              ></div>`}
        </div>
      </div>

      ${this.editable?V`<div class="hint">${this.translations?.clickToEdit??""}</div>`:""}
    `}render(){return this.scheduleData?this._isMobile?this._renderMobile():this._renderDesktop():V``}static{this.styles=qt}};Jt([ht({attribute:!1})],Xt.prototype,"scheduleData",void 0),Jt([ht({type:Boolean})],Xt.prototype,"editable",void 0),Jt([ht({type:Boolean})],Xt.prototype,"showTemperature",void 0),Jt([ht({type:Boolean})],Xt.prototype,"showGradient",void 0),Jt([ht({type:String})],Xt.prototype,"temperatureUnit",void 0),Jt([ht({type:String})],Xt.prototype,"hourFormat",void 0),Jt([ht({attribute:!1})],Xt.prototype,"translations",void 0),Jt([ht({type:String})],Xt.prototype,"copiedWeekday",void 0),Jt([ht({type:Boolean})],Xt.prototype,"editorOpen",void 0),Jt([ht({type:String})],Xt.prototype,"currentProfile",void 0),Jt([ht({type:String})],Xt.prototype,"scheduleDataHash",void 0),Jt([pt()],Xt.prototype,"_currentTimePercent",void 0),Jt([pt()],Xt.prototype,"_currentTimeMinutes",void 0),Jt([pt()],Xt.prototype,"_currentWeekday",void 0),Jt([pt()],Xt.prototype,"_isMobile",void 0),Jt([pt()],Xt.prototype,"_mobileSelectedDayIndex",void 0),Xt=Jt([Pt("hmip-schedule-grid")],Xt);const Gt=o`
  :host {
    display: block;
  }

  /* Dialog styles */
  ha-dialog {
    --ha-dialog-max-width: 90vw;
    --ha-dialog-max-height: 90vh;
  }

  .dialog-content {
    display: flex;
    flex-direction: column;
    gap: 16px;
    padding: 16px;
    overflow-y: auto;
    max-height: calc(90vh - 200px);
  }

  .weekday-tabs {
    display: flex;
    gap: 4px;
    flex-wrap: wrap;
    justify-content: center;
  }

  .weekday-tab {
    padding: 8px 12px;
    border: 1px solid var(--divider-color);
    border-radius: 4px;
    background-color: var(--card-background-color);
    color: var(--primary-text-color);
    font-size: 14px;
    cursor: pointer;
    transition:
      background-color 0.2s,
      border-color 0.2s;
    min-width: 40px;
    text-align: center;
  }

  .weekday-tab:hover {
    background-color: var(--divider-color);
  }

  .weekday-tab.active {
    background-color: var(--primary-color);
    color: var(--text-primary-color, #fff);
    border-color: var(--primary-color);
  }

  .dialog-editor {
    flex: 1;
    min-height: 0;
  }

  .dialog-editor .editor {
    box-shadow: none;
    border: none;
    padding: 0;
  }

  .dialog-editor .editor-header {
    display: none;
  }

  .dialog-editor .editor-footer {
    display: flex;
  }

  /* Editor Styles */
  .editor {
    background-color: var(--card-background-color);
  }

  .editor-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 16px;
    padding-bottom: 12px;
    border-bottom: 1px solid var(--divider-color);
  }

  .editor-header h3 {
    margin: 0;
    font-size: 20px;
    font-weight: 500;
  }

  .editor-actions {
    display: flex;
    gap: 4px;
    align-items: center;
  }

  .editor-actions ha-icon-button {
    --ha-icon-button-size: 36px;
    color: var(--secondary-text-color);
  }

  .editor-actions ha-icon-button[disabled] {
    opacity: 0.5;
  }

  ha-alert {
    margin: 12px 0;
  }

  .warnings-list {
    margin: 0;
    padding-left: 20px;
    list-style-type: disc;
  }

  .warning-item {
    font-size: 13px;
    line-height: 1.6;
    margin: 4px 0;
  }

  /* Base Temperature Section */
  .base-temperature-section {
    background-color: rgba(var(--rgb-primary-color, 3, 169, 244), 0.1);
    border: 1px solid var(--divider-color);
    border-radius: 4px;
    padding: 12px;
    margin: 12px 0;
  }

  .base-temperature-header {
    display: flex;
    flex-direction: column;
    gap: 4px;
    margin-bottom: 8px;
  }

  .base-temp-label {
    font-weight: 500;
    font-size: 14px;
    color: var(--primary-text-color);
  }

  .base-temp-description {
    font-size: 12px;
    color: var(--secondary-text-color);
  }

  .base-temperature-input {
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .base-temp-input {
    width: 80px;
    font-weight: 500;
  }

  .editor-content-label {
    font-weight: 500;
    font-size: 14px;
    color: var(--primary-text-color);
    margin: 16px 0 8px 0;
    padding-left: 8px;
  }

  .editor-content {
    max-height: 500px;
    overflow-y: auto;
  }

  .time-block-header {
    display: grid;
    grid-template-columns: minmax(80px, 100px) minmax(80px, 100px) minmax(70px, 90px) 1fr 24px;
    gap: 8px;
    align-items: center;
    padding: 8px;
    border-bottom: 2px solid var(--divider-color);
    font-weight: 500;
    font-size: 12px;
    color: var(--secondary-text-color);
    text-transform: uppercase;
  }

  .header-cell {
    text-align: left;
  }

  .time-block-editor {
    display: grid;
    grid-template-columns: minmax(80px, 100px) minmax(80px, 100px) minmax(70px, 90px) 1fr 24px;
    gap: 8px;
    align-items: center;
    padding: 8px;
    border-bottom: 1px solid var(--divider-color);
  }

  .time-block-editor.editing {
    background-color: var(--primary-color-light, rgba(3, 169, 244, 0.1));
    border: 1px solid var(--primary-color);
    border-radius: 4px;
    margin: 4px 0;
  }

  .time-block-editor.base-temp-slot {
    opacity: 0.6;
    background-color: var(--divider-color);
  }

  .time-display {
    font-size: 14px;
    color: var(--primary-text-color);
    font-family: monospace;
  }

  .temp-display-group,
  .temp-input-group {
    display: flex;
    align-items: center;
    gap: 4px;
  }

  .temp-display {
    font-size: 14px;
    color: var(--primary-text-color);
    font-weight: 500;
  }

  .slot-actions {
    display: flex;
    gap: 4px;
    justify-content: flex-end;
  }

  .slot-actions ha-button {
    font-size: 12px;
  }

  ha-button[disabled] {
    opacity: 0.5;
  }

  .block-number {
    font-weight: 500;
    color: var(--secondary-text-color);
  }

  .time-input,
  .temp-input {
    padding: 6px 8px;
    border: 1px solid var(--divider-color);
    border-radius: 4px;
    background-color: var(--card-background-color);
    color: var(--primary-text-color);
    font-size: 14px;
    width: 100%;
    box-sizing: border-box;
  }

  .time-input {
    min-width: 70px;
    max-width: 120px;
  }

  .temp-input {
    max-width: 60px;
  }

  .temp-unit {
    color: var(--secondary-text-color);
    font-size: 14px;
  }

  .remove-btn {
    --ha-icon-button-size: 32px;
    color: var(--secondary-text-color);
  }

  .remove-btn[disabled] {
    opacity: 0.5;
  }

  .color-indicator {
    width: 20px;
    height: 20px;
    border-radius: 4px;
    border: 1px solid var(--divider-color);
    flex-shrink: 0;
  }

  .add-btn {
    margin: 12px 0;
    width: 100%;
    --ha-button-color: var(--primary-color);
  }

  .editor-footer {
    display: flex;
    justify-content: flex-end;
    gap: 12px;
    margin-top: 16px;
    padding-top: 16px;
    border-top: 1px solid var(--divider-color);
  }

  /* Mobile Optimization */
  @media (max-width: 768px) {
    ha-dialog {
      --ha-dialog-max-width: 100vw;
      --ha-dialog-max-height: 100vh;
    }

    .dialog-content {
      max-height: calc(100vh - 150px);
    }

    .editor-header h3 {
      font-size: 18px;
    }

    .editor-actions ha-icon-button {
      --ha-icon-button-size: 44px;
    }

    .editor-content {
      max-height: 400px;
    }

    .time-block-editor {
      grid-template-columns: 30px 1fr 70px 40px 44px 20px;
      gap: 6px;
      padding: 10px 6px;
    }

    .block-number {
      font-size: 13px;
    }

    .time-input,
    .temp-input {
      padding: 10px 8px;
      font-size: 16px;
      min-height: 44px;
    }

    .temp-unit {
      font-size: 13px;
    }

    .editor-footer {
      flex-direction: column-reverse;
      gap: 8px;
    }

    .editor-footer ha-button {
      width: 100%;
    }

    .warning-item {
      font-size: 12px;
    }
  }

  /* Small mobile devices (portrait phones) */
  @media (max-width: 480px) {
    .time-block-editor {
      grid-template-columns: 25px 1fr 60px 35px 44px 16px;
      gap: 4px;
      padding: 8px 4px;
    }

    .block-number {
      font-size: 12px;
    }

    .editor-header h3 {
      font-size: 16px;
    }
  }

  /* Landscape mobile optimization */
  @media (max-width: 768px) and (orientation: landscape) {
    .editor-content {
      max-height: calc(100vh - 200px);
    }
  }
`;var Kt=function(t,e,i,s){var n,a=arguments.length,o=a<3?e:null===s?s=Object.getOwnPropertyDescriptor(e,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)o=Reflect.decorate(t,e,i,s);else for(var r=t.length-1;r>=0;r--)(n=t[r])&&(o=(a<3?n(o):a>3?n(e,i,o):n(e,i))||o);return a>3&&o&&Object.defineProperty(e,i,o),o};let Qt=class extends rt{constructor(){super(),this.open=!1,this.minTemp=5,this.maxTemp=30.5,this.tempStep=.5,this.temperatureUnit="°C",this.hourFormat="24",this._validationWarnings=[],this._historyStack=[],this._historyIndex=-1,this._keyDownHandler=this._handleKeyDown.bind(this)}connectedCallback(){super.connectedCallback(),window.addEventListener("keydown",this._keyDownHandler)}disconnectedCallback(){super.disconnectedCallback(),window.removeEventListener("keydown",this._keyDownHandler)}willUpdate(t){if(super.willUpdate(t),(t.has("open")||t.has("weekday"))&&this.open&&this.weekday){const e=t.get("open"),i=t.get("weekday");(!e&&this.open||this.open&&i!==this.weekday)&&this._initializeEditor(this.weekday)}}updated(t){super.updated(t),t.has("open")&&this.open&&!t.get("open")&&this.updateComplete.then(()=>{const t=this.shadowRoot?.querySelector(".weekday-tab, .base-temp-input, ha-button");t?.focus()})}_initializeEditor(t){this._editingWeekday=t,this._editingBlocks=this._getParsedBlocks(t),this._editingSlotIndex=void 0,this._editingSlotData=void 0;const e=this.scheduleData?.[t];if(e){const{baseTemperature:t}=xt(e);this._editingBaseTemperature=t}else this._editingBaseTemperature=20;this._historyStack=[JSON.parse(JSON.stringify(this._editingBlocks))],this._historyIndex=0,this._updateValidationWarnings()}_getParsedBlocks(t){if(this.scheduleData){const e=this.scheduleData[t];if(!e)return[];const{blocks:i}=xt(e);return i}return[]}_getWeekdayLabel(t,e){return"long"===e?this.translations?.weekdayLongLabels[t]??t:this.translations?.weekdayShortLabels[t]??t.slice(0,2)}_formatTimeDisplay(t){return yt(t,this.hourFormat)}_formatValidationParams(t){if(!t)return{};const e={};for(const[i,s]of Object.entries(t))"weekday"===i&&ut.includes(s)?e.weekday=this._getWeekdayLabel(s,"long"):e[i]=s;return e}_translateValidationMessage(t){const e=this.translations?.validationMessages[t.key]||t.key,i=this._formatValidationParams(t.params);t.nested&&(i.details=this._translateValidationMessage(t.nested));let s=e;for(const[t,e]of Object.entries(i))s=s.replace(`{${t}}`,e);return s}_saveHistoryState(){if(!this._editingBlocks)return;const t=JSON.parse(JSON.stringify(this._editingBlocks));this._historyStack=this._historyStack.slice(0,this._historyIndex+1),this._historyStack.push(t),this._historyIndex++,this._historyStack.length>50&&(this._historyStack.shift(),this._historyIndex--)}_undo(){this._historyIndex<=0||(this._historyIndex--,this._editingBlocks=JSON.parse(JSON.stringify(this._historyStack[this._historyIndex])),this._updateValidationWarnings())}_redo(){this._historyIndex>=this._historyStack.length-1||(this._historyIndex++,this._editingBlocks=JSON.parse(JSON.stringify(this._historyStack[this._historyIndex])),this._updateValidationWarnings())}_canUndo(){return this._historyIndex>0}_canRedo(){return this._historyIndex<this._historyStack.length-1}_handleKeyDown(t){if(!this.open||!this._editingWeekday||!this._editingBlocks)return;const e=t.ctrlKey||t.metaKey;e&&"z"===t.key&&!t.shiftKey?(t.preventDefault(),this._undo()):e&&("y"===t.key||"z"===t.key&&t.shiftKey)&&(t.preventDefault(),this._redo())}_updateValidationWarnings(){this._validationWarnings=this._editingBlocks?function(t,e=5,i=30.5){const s=[];if(0===t.length)return s;for(let e=0;e<t.length-1;e++){const i=t[e];i.endMinutes<i.startMinutes&&s.push({key:"blockEndBeforeStart",params:{block:`${e+1}`}}),i.endMinutes===i.startMinutes&&s.push({key:"blockZeroDuration",params:{block:`${e+1}`}})}const n=t[t.length-1];return n.endMinutes<n.startMinutes&&s.push({key:"blockEndBeforeStart",params:{block:`${t.length}`}}),t.forEach((t,n)=>{(t.startMinutes<0||t.startMinutes>1440)&&s.push({key:"invalidStartTime",params:{block:`${n+1}`}}),(t.endMinutes<0||t.endMinutes>1440)&&s.push({key:"invalidEndTime",params:{block:`${n+1}`}}),(t.temperature<e||t.temperature>i)&&s.push({key:"temperatureOutOfRange",params:{block:`${n+1}`,min:`${e}`,max:`${i}`}})}),s}(this._editingBlocks,this.minTemp,this.maxTemp):[]}_startSlotEdit(t){if(!this._editingBlocks||t<0||t>=this._editingBlocks.length)return;const e=this._editingBlocks[t];this._editingSlotIndex=t,this._editingSlotData={startTime:e.startTime,endTime:e.endTime,temperature:e.temperature}}_startSlotEditFromDisplay(t,e){if(!this._editingBlocks)return;const i=e[t],s=this._editingBlocks.findIndex(t=>t.startMinutes===i.startMinutes&&t.endMinutes===i.endMinutes&&t.temperature===i.temperature);-1!==s&&this._startSlotEdit(s)}_cancelSlotEdit(){this._editingSlotIndex=void 0,this._editingSlotData=void 0}_saveSlotEdit(){if(void 0===this._editingSlotIndex||!this._editingSlotData||!this._editingBlocks||void 0===this._editingBaseTemperature)return;const t=this._editingSlotIndex,{startTime:e,endTime:i,temperature:s}=this._editingSlotData,n={startTime:e,startMinutes:_t(e),endTime:i,endMinutes:_t(i),temperature:s,slot:t+1},a=this._editingBlocks.filter((e,i)=>i!==t),o=function(t,e){const i=[],s=e.startMinutes,n=e.endMinutes,a=[...t].sort((t,e)=>t.startMinutes-e.startMinutes);for(const t of a){const e=t.startMinutes,a=t.endMinutes;a<=s||e>=n?i.push(t):(e<s&&i.push({...t,endTime:ft(s),endMinutes:s,slot:i.length+1}),a>n&&i.push({...t,startTime:ft(n),startMinutes:n,slot:i.length+1}))}i.push({...e,slot:i.length+1});const o=i.sort((t,e)=>t.startMinutes-e.startMinutes);return $t(o)}(a,n),r=$t(kt(o));this._saveHistoryState(),this._editingBlocks=r,this._editingSlotIndex=void 0,this._editingSlotData=void 0,this._updateValidationWarnings()}_addNewSlot(){if(!this._editingBlocks||void 0===this._editingBaseTemperature)return;if(this._editingBlocks.length>=12)return;let t=0,e=60;if(this._editingBlocks.length>0){const i=kt(this._editingBlocks),s=i[i.length-1];if(s.endMinutes<1440)t=s.endMinutes,e=Math.min(t+60,1440);else{let s=!1;for(let n=0;n<i.length;n++){const a=0===n?0:i[n-1].endMinutes;if(i[n].startMinutes>a){t=a,e=i[n].startMinutes,s=!0;break}}if(!s)return}}const i=Math.min(this._editingBaseTemperature+2,this.maxTemp),s={startTime:ft(t),startMinutes:t,endTime:ft(e),endMinutes:e,temperature:i,slot:this._editingBlocks.length+1};this._saveHistoryState();const n=kt([...this._editingBlocks,s]);this._editingBlocks=n;const a=n.findIndex(i=>i.startMinutes===t&&i.endMinutes===e);a>=0&&this._startSlotEdit(a),this._updateValidationWarnings()}_removeTimeBlockByIndex(t,e){if(!this._editingBlocks||void 0===this._editingBaseTemperature)return;const i=e[t],s=this._editingBlocks.findIndex(t=>t.startMinutes===i.startMinutes&&t.endMinutes===i.endMinutes&&t.temperature===i.temperature);if(-1===s)return;this._saveHistoryState();const n=this._editingBlocks.filter((t,e)=>e!==s);this._editingBlocks=$t(kt(n)),this._updateValidationWarnings()}_switchToWeekday(t){t!==this._editingWeekday&&this._initializeEditor(t)}_closeEditor(){this._editingWeekday=void 0,this._editingBlocks=void 0,this._editingBaseTemperature=void 0,this._editingSlotIndex=void 0,this._editingSlotData=void 0,this._historyStack=[],this._historyIndex=-1,this.dispatchEvent(new CustomEvent("editor-closed",{bubbles:!0,composed:!0}))}_saveSchedule(){if(!this._editingWeekday||!this._editingBlocks||void 0===this._editingBaseTemperature)return;const t=function(t,e){const i=[],s=[...t].sort((t,e)=>t.startMinutes-e.startMinutes);for(const t of s)i.push({starttime:t.startTime,endtime:t.endTime,temperature:t.temperature});return{base_temperature:e,periods:i}}(this._editingBlocks,this._editingBaseTemperature),e=function(t,e=5,i=30.5){const{base_temperature:s,periods:n}=t;if(s<e||s>i)return{key:"temperatureOutOfRange",params:{block:"base",min:`${e}`,max:`${i}`}};let a=0;for(let t=0;t<n.length;t++){const s=n[t];if(!s.starttime||!s.endtime||void 0===s.temperature)return{key:"slotMissingValues",params:{slot:`${t+1}`}};const o=_t(s.starttime),r=_t(s.endtime);if(r<=o)return{key:"blockEndBeforeStart",params:{block:`${t+1}`}};if(o<a)return{key:"slotTimeBackwards",params:{slot:`${t+1}`,time:s.starttime}};if(s.temperature<e||s.temperature>i)return{key:"temperatureOutOfRange",params:{block:`${t+1}`,min:`${e}`,max:`${i}`}};a=r}return null}(t,this.minTemp,this.maxTemp);if(e){const t=this._translateValidationMessage(e);return void this.dispatchEvent(new CustomEvent("validation-failed",{detail:{error:t},bubbles:!0,composed:!0}))}this.dispatchEvent(new CustomEvent("save-schedule",{detail:{weekday:this._editingWeekday,blocks:this._editingBlocks,baseTemperature:this._editingBaseTemperature},bubbles:!0,composed:!0}))}render(){return this.open&&this._editingWeekday?V`
      <ha-dialog
        open
        @closed=${this._closeEditor}
        .heading=${this._formatEdit(this._editingWeekday)}
      >
        <div class="dialog-content">
          <!-- Weekday selector tabs -->
          <div class="weekday-tabs">
            ${ut.map(t=>V`
                <button
                  class="weekday-tab ${t===this._editingWeekday?"active":""}"
                  @click=${()=>this._switchToWeekday(t)}
                >
                  ${this._getWeekdayLabel(t,"short")}
                </button>
              `)}
          </div>

          <!-- Editor content in dialog -->
          <div class="dialog-editor">${this._renderEditor()}</div>
        </div>
      </ha-dialog>
    `:V``}_formatEdit(t){return(this.translations?.edit??"Edit {weekday}").replace("{weekday}",this._getWeekdayLabel(t,"long"))}_renderEditor(){if(!this._editingWeekday||!this._editingBlocks)return V``;const t=void 0!==this._editingBaseTemperature?wt(this._editingBlocks,this._editingBaseTemperature):this._editingBlocks;return V`
      <div class="editor">
        <div class="editor-header">
          <h3>${this._formatEdit(this._editingWeekday)}</h3>
          <div class="editor-actions">
            <ha-icon-button
              .path=${"M12.5,8C9.85,8 7.45,9 5.6,10.6L2,7V16H11L7.38,12.38C8.77,11.22 10.54,10.5 12.5,10.5C16.04,10.5 19.05,12.81 20.1,16L22.47,15.22C21.08,11.03 17.15,8 12.5,8Z"}
              @click=${this._undo}
              .disabled=${!this._canUndo()}
              .label=${this.translations?.undoShortcut??"Undo"}
            ></ha-icon-button>
            <ha-icon-button
              .path=${"M18.4,10.6C16.55,9 14.15,8 11.5,8C6.85,8 2.92,11.03 1.54,15.22L3.9,16C4.95,12.81 7.95,10.5 11.5,10.5C13.45,10.5 15.23,11.22 16.62,12.38L13,16H22V7L18.4,10.6Z"}
              @click=${this._redo}
              .disabled=${!this._canRedo()}
              .label=${this.translations?.redoShortcut??"Redo"}
            ></ha-icon-button>
            <ha-icon-button
              .path=${"M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z"}
              @click=${this._closeEditor}
              .label=${this.translations?.close??"Close"}
            ></ha-icon-button>
          </div>
        </div>

        <div aria-live="polite">
          ${this._validationWarnings.length>0?V`
                <ha-alert alert-type="warning" .title=${this.translations?.warningsTitle??""}>
                  <ul class="warnings-list">
                    ${this._validationWarnings.map(t=>V`<li class="warning-item">
                          ${this._translateValidationMessage(t)}
                        </li>`)}
                  </ul>
                </ha-alert>
              `:""}
        </div>

        <!-- Base Temperature Section -->
        <div class="base-temperature-section">
          <div class="base-temperature-header">
            <span class="base-temp-label">${this.translations?.baseTemperature??""}</span>
            <span class="base-temp-description"
              >${this.translations?.baseTemperatureDescription??""}</span
            >
          </div>
          <div class="base-temperature-input">
            <input
              type="number"
              class="temp-input base-temp-input"
              .value=${this._editingBaseTemperature?.toString()||"20.0"}
              step=${this.tempStep}
              min=${this.minTemp}
              max=${this.maxTemp}
              @change=${t=>{this._saveHistoryState(),this._editingBaseTemperature=parseFloat(t.target.value),this.requestUpdate()}}
            />
            <span class="temp-unit">${this.temperatureUnit}</span>
            <div
              class="color-indicator"
              style="background-color: ${bt(this._editingBaseTemperature||20)}"
            ></div>
          </div>
        </div>

        <div class="editor-content-label">${this.translations?.temperaturePeriods??""}</div>
        <div class="editor-content">
          <div class="time-block-header">
            <span class="header-cell header-from">${this.translations?.from??""}</span>
            <span class="header-cell header-to">${this.translations?.to??""}</span>
            <span class="header-cell header-temp">Temp</span>
            <span class="header-cell header-actions"></span>
          </div>
          ${t.map((e,i)=>{const s=this._editingBlocks.findIndex(t=>t.startMinutes===e.startMinutes&&t.endMinutes===e.endMinutes),n=!(-1!==s);return void 0!==this._editingSlotIndex&&this._editingSlotIndex===s&&void 0!==this._editingSlotData&&this._editingSlotData?V`
                <div class="time-block-editor editing">
                  <input
                    type="time"
                    class="time-input"
                    .value=${this._editingSlotData.startTime}
                    @change=${t=>{this._editingSlotData&&(this._editingSlotData={...this._editingSlotData,startTime:t.target.value},this.requestUpdate())}}
                  />
                  <input
                    type="time"
                    class="time-input"
                    .value=${"24:00"===this._editingSlotData.endTime?"23:59":this._editingSlotData.endTime}
                    @change=${t=>{if(this._editingSlotData){let e=t.target.value;"23:59"===e&&(e="24:00"),this._editingSlotData={...this._editingSlotData,endTime:e},this.requestUpdate()}}}
                  />
                  <div class="temp-input-group">
                    <input
                      type="number"
                      class="temp-input"
                      .value=${this._editingSlotData.temperature.toString()}
                      step=${this.tempStep}
                      min=${this.minTemp}
                      max=${this.maxTemp}
                      @change=${t=>{this._editingSlotData&&(this._editingSlotData={...this._editingSlotData,temperature:parseFloat(t.target.value)},this.requestUpdate())}}
                    />
                    <span class="temp-unit">${this.temperatureUnit}</span>
                  </div>
                  <div class="slot-actions">
                    <ha-button @click=${this._saveSlotEdit}>
                      ${this.translations?.saveSlot??"Save"}
                    </ha-button>
                    <ha-button @click=${this._cancelSlotEdit}>
                      ${this.translations?.cancelSlotEdit??"Cancel"}
                    </ha-button>
                  </div>
                  <div
                    class="color-indicator"
                    style="background-color: ${bt(this._editingSlotData.temperature)}"
                  ></div>
                </div>
              `:V`
              <div class="time-block-editor ${n?"base-temp-slot":""}">
                <span class="time-display">${this._formatTimeDisplay(e.startTime)}</span>
                <span class="time-display">${this._formatTimeDisplay(e.endTime)}</span>
                <div class="temp-display-group">
                  <span class="temp-display">${e.temperature.toFixed(1)}</span>
                  <span class="temp-unit">${this.temperatureUnit}</span>
                </div>
                <div class="slot-actions">
                  ${n?V``:V`
                        <ha-button
                          @click=${()=>this._startSlotEditFromDisplay(i,t)}
                          .disabled=${void 0!==this._editingSlotIndex}
                        >
                          ${this.translations?.editSlot??"Edit"}
                        </ha-button>
                        <ha-icon-button
                          class="remove-btn"
                          .path=${"M19,4H15.5L14.5,3H9.5L8.5,4H5V6H19M6,19A2,2 0 0,0 8,21H16A2,2 0 0,0 18,19V7H6V19Z"}
                          @click=${()=>this._removeTimeBlockByIndex(i,t)}
                          .disabled=${void 0!==this._editingSlotIndex}
                          .label=${this.translations?.removeSlot??"Remove"}
                        ></ha-icon-button>
                      `}
                </div>
                <div
                  class="color-indicator"
                  style="background-color: ${bt(e.temperature)}"
                ></div>
              </div>
            `})}
          ${this._editingBlocks.length<12&&void 0===this._editingSlotIndex?V`
                <ha-button class="add-btn" @click=${this._addNewSlot}>
                  ${this.translations?.addTimeBlock??"+ Add Time Block"}
                </ha-button>
              `:""}
        </div>

        <div class="editor-footer">
          <ha-button @click=${this._closeEditor}>
            ${this.translations?.cancel??"Cancel"}
          </ha-button>
          <ha-button @click=${this._saveSchedule}> ${this.translations?.save??"Save"} </ha-button>
        </div>
      </div>
    `}static{this.styles=Gt}};Kt([ht({type:Boolean})],Qt.prototype,"open",void 0),Kt([ht({type:String})],Qt.prototype,"weekday",void 0),Kt([ht({attribute:!1})],Qt.prototype,"scheduleData",void 0),Kt([ht({type:Number})],Qt.prototype,"minTemp",void 0),Kt([ht({type:Number})],Qt.prototype,"maxTemp",void 0),Kt([ht({type:Number})],Qt.prototype,"tempStep",void 0),Kt([ht({type:String})],Qt.prototype,"temperatureUnit",void 0),Kt([ht({type:String})],Qt.prototype,"hourFormat",void 0),Kt([ht({attribute:!1})],Qt.prototype,"translations",void 0),Kt([pt()],Qt.prototype,"_editingWeekday",void 0),Kt([pt()],Qt.prototype,"_editingBlocks",void 0),Kt([pt()],Qt.prototype,"_editingBaseTemperature",void 0),Kt([pt()],Qt.prototype,"_validationWarnings",void 0),Kt([pt()],Qt.prototype,"_editingSlotIndex",void 0),Kt([pt()],Qt.prototype,"_editingSlotData",void 0),Qt=Kt([Pt("hmip-schedule-editor")],Qt);const te=o`
  :host {
    display: block;
  }

  .schedule-list {
    display: flex;
    flex-direction: column;
  }

  .toolbar {
    margin-bottom: 16px;
    display: flex;
    justify-content: flex-end;
  }

  ha-button {
    --ha-button-color: var(--primary-color);
  }

  .no-data {
    text-align: center;
    padding: 32px;
    color: var(--secondary-text-color);
  }

  .events-table {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }

  .event-card {
    border: 1px solid var(--divider-color);
    border-radius: 8px;
    overflow: hidden;
    transition: background-color 0.2s;
  }

  .event-card.inactive {
    opacity: 0.5;
  }

  .event-card:hover {
    background-color: rgba(var(--rgb-primary-color, 3, 169, 244), 0.05);
  }

  .event-row-top {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 16px 4px;
    gap: 8px;
  }

  .col-condition {
    font-weight: 500;
    font-size: 14px;
    color: var(--primary-text-color);
    flex: 1;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .col-actions {
    display: flex;
    gap: 0;
    flex-shrink: 0;
  }

  ha-icon-button {
    --ha-icon-button-size: 36px;
    color: var(--secondary-text-color);
  }

  .event-row-details {
    padding: 0 16px 4px;
  }

  .col-details-text {
    font-size: 13px;
    color: var(--secondary-text-color);
  }

  .event-row-bottom {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 16px 10px;
    gap: 12px;
  }

  .col-weekdays {
    flex: 1;
    min-width: 0;
    overflow: hidden;
  }

  .weekday-badges {
    display: flex;
    gap: 3px;
    flex-wrap: wrap;
  }

  .weekday-badge {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 26px;
    padding: 2px 4px;
    border-radius: 4px;
    font-size: 11px;
    font-weight: 500;
    line-height: 1;
  }

  .weekday-badge.active {
    background-color: var(--primary-color);
    color: var(--text-primary-color);
  }

  .weekday-badge.inactive {
    background-color: var(--divider-color);
    color: var(--disabled-text-color, var(--secondary-text-color));
    opacity: 0.5;
  }

  .col-details {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-shrink: 0;
    font-size: 13px;
  }

  .col-state {
    color: var(--primary-text-color);
  }

  .col-state .level-2 {
    color: var(--secondary-text-color);
    font-size: 0.9em;
  }

  .col-duration {
    color: var(--secondary-text-color);
  }

  /* Mobile Optimization */
  @media (max-width: 768px) {
    .event-row-top {
      padding: 8px 12px 4px;
    }

    .event-row-details {
      padding: 0 12px 4px;
    }

    .event-row-bottom {
      padding: 0 12px 8px;
      flex-wrap: wrap;
    }

    ha-icon-button {
      --ha-icon-button-size: 44px;
    }

    .weekday-badge {
      min-width: 22px;
      padding: 2px 3px;
      font-size: 10px;
    }
  }

  @media (max-width: 480px) {
    .col-condition {
      font-size: 13px;
    }

    .weekday-badge {
      min-width: 20px;
      padding: 1px 2px;
      font-size: 9px;
    }
  }

  /* Swipe-to-delete wrapper */
  .event-card-wrapper {
    position: relative;
    overflow: hidden;
    border-radius: 8px;
  }

  .swipe-delete-bg {
    position: absolute;
    right: 0;
    top: 0;
    bottom: 0;
    width: 80px;
    background: var(--error-color, #db4437);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    border-radius: 0 8px 8px 0;
  }

  .swipe-delete-bg ha-icon {
    --ha-icon-display-size: 24px;
    color: white;
  }

  .event-card.swiping {
    transition: none !important;
  }

  /* Touch device optimizations */
  @media (hover: none) and (pointer: coarse) {
    .event-card:hover {
      background-color: transparent;
    }

    .event-card:active {
      background-color: rgba(var(--rgb-primary-color, 3, 169, 244), 0.1);
    }

    .event-card:not(.swiping) {
      transition:
        transform 0.2s ease-out,
        background-color 0.2s;
    }
  }
`;var ee=function(t,e,i,s){var n,a=arguments.length,o=a<3?e:null===s?s=Object.getOwnPropertyDescriptor(e,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)o=Reflect.decorate(t,e,i,s);else for(var r=t.length-1;r>=0;r--)(n=t[r])&&(o=(a<3?n(o):a>3?n(e,i,o):n(e,i))||o);return a>3&&o&&Object.defineProperty(e,i,o),o};let ie=class extends rt{constructor(){super(...arguments),this.editable=!0,this._swipeX=0,this._touchStartX=0,this._touchStartY=0,this._isSwiping=!1,this._isScrolling=!1}static{this.styles=te}_onTouchStart(t,e){if(!this.editable)return;const i=t.touches[0];this._touchStartX=i.clientX,this._touchStartY=i.clientY,this._isSwiping=!1,this._isScrolling=!1,this._swipingGroupNo=e,this._swipeX=0}_onTouchMove(t){if(!this._swipingGroupNo)return;const e=t.touches[0],i=e.clientX-this._touchStartX;if(!this._isSwiping&&!this._isScrolling){if(Math.abs(e.clientY-this._touchStartY)>10)return this._isScrolling=!0,this._swipingGroupNo=void 0,void(this._swipeX=0);Math.abs(i)>10&&(this._isSwiping=!0)}this._isScrolling||this._isSwiping&&(t.preventDefault(),this._swipeX=Math.min(0,i))}_onTouchEnd(t){this._swipingGroupNo&&this._isSwiping?Math.abs(this._swipeX)>=120?(this.dispatchEvent(new CustomEvent("delete-event",{bubbles:!0,composed:!0,detail:{entry:t}})),this._resetSwipe()):(this._swipeX=0,setTimeout(()=>this._resetSwipe(),200)):this._resetSwipe()}_resetSwipe(){this._swipingGroupNo=void 0,this._swipeX=0,this._isSwiping=!1,this._isScrolling=!1}_handleAdd(){this.dispatchEvent(new CustomEvent("add-event",{bubbles:!0,composed:!0}))}_handleEdit(t){this.dispatchEvent(new CustomEvent("edit-event",{bubbles:!0,composed:!0,detail:{entry:t}}))}_handleDelete(t){this.dispatchEvent(new CustomEvent("delete-event",{bubbles:!0,composed:!0,detail:{entry:t}}))}_getConditionDisplay(t){return function(t,e,i){const s=function(t,e,i){const s="sunset"===t?i.sunset:i.sunrise;return 0===e?s:`${s} ${e>0?"+":""}${e}min`}(t.astro_type,t.astro_offset_minutes,i),n=t.time;switch(t.condition){case"fixed_time":default:return{label:e,details:n};case"astro":return{label:e,details:s};case"earliest":case"latest":case"astro_if_before_fixed":case"astro_if_after_fixed":return{label:e,details:`${s} / ${n}`};case"fixed_if_before_astro":case"fixed_if_after_astro":return{label:e,details:`${n} / ${s}`}}}(t,this.translations.conditionLabels[t.condition]||t.condition,this.translations.conditionSummaryLabels)}render(){if(!this.scheduleData)return V`<div class="no-data">${this.translations.loading}</div>`;const t=function(t){const e=[];for(const[i,s]of Object.entries(t))e.push({...s,groupNo:i,isActive:Et(s)});return e.sort((t,e)=>t.time.localeCompare(e.time)),e}(this.scheduleData);return 0===t.length?V`
        <div class="no-data">
          <p>${this.translations.noScheduleEvents}</p>
          ${this.editable?V`<ha-button @click=${this._handleAdd}> ${this.translations.addEvent} </ha-button>`:""}
        </div>
      `:V`
      <div class="schedule-list">
        ${this.editable?V`<div class="toolbar">
              <ha-button @click=${this._handleAdd}> ${this.translations.addEvent} </ha-button>
            </div>`:""}
        <div class="events-table">
          ${Zt(t,t=>t.groupNo,t=>this._renderEvent(t))}
        </div>
      </div>
    `}_renderEvent(t){const e=function(t,e,i){const s=e?gt[e]:void 0;if("binary"===s?.levelType){const e=i?.on??"On";return 0===t?i?.off??"Off":e}return`${Math.round(100*t)}%`}(t.level,this.domain,{on:this.translations.levelOn,off:this.translations.levelOff}),i=function(t){if(!t)return"-";const e=Tt(t);return e?`${e.value}${{ms:"ms",s:"s",min:"min",h:"h"}[e.unit]}`:t}(t.duration),{label:s,details:n}=this._getConditionDisplay(t),a=this._swipingGroupNo===t.groupNo,o=a?this._swipeX:0;return V`
      <div class="event-card-wrapper">
        ${a&&o<-40?V`<div class="swipe-delete-bg">
              <ha-icon .icon=${"mdi:delete"}></ha-icon>
            </div>`:""}
        <div
          class="event-card ${t.isActive?"active":"inactive"} ${a&&this._isSwiping?"swiping":""}"
          style=${a&&this._isSwiping?`transform: translateX(${o}px)`:""}
          @touchstart=${e=>this._onTouchStart(e,t.groupNo)}
          @touchmove=${t=>this._onTouchMove(t)}
          @touchend=${()=>this._onTouchEnd(t)}
        >
          <div class="event-row-top">
            <div class="col-condition">${s}</div>
            ${this.editable?V`<div class="col-actions">
                  <ha-icon-button
                    .path=${"M20.71,7.04C21.1,6.65 21.1,6 20.71,5.63L18.37,3.29C18,2.9 17.35,2.9 16.96,3.29L15.12,5.12L18.87,8.87M3,17.25V21H6.75L17.81,9.93L14.06,6.18L3,17.25Z"}
                    @click=${()=>this._handleEdit(t)}
                    .label=${this.translations?.editEvent??"Edit"}
                  ></ha-icon-button>
                  <ha-icon-button
                    .path=${"M19,4H15.5L14.5,3H9.5L8.5,4H5V6H19M6,19A2,2 0 0,0 8,21H16A2,2 0 0,0 18,19V7H6V19Z"}
                    @click=${()=>this._handleDelete(t)}
                    .label=${this.translations?.deleteEvent??"Delete"}
                  ></ha-icon-button>
                </div>`:""}
          </div>
          <div class="event-row-details">
            <span class="col-details-text">${n}</span>
          </div>
          <div class="event-row-bottom">
            <div class="col-weekdays">
              <div class="weekday-badges">
                ${ut.map(e=>{const i=t.weekdays.includes(e);return V`<span class="weekday-badge ${i?"active":"inactive"}"
                    >${this.translations.weekdayShortLabels[e]}</span
                  >`})}
              </div>
            </div>
            <div class="col-details">
              <span class="col-state">
                ${e}
                ${null!==t.level_2?V`<span class="level-2"
                      >, ${this.translations.slat}: ${Math.round(100*t.level_2)}%</span
                    >`:""}
              </span>
              ${"-"!==i?V`<span class="col-duration">${i}</span>`:""}
            </div>
          </div>
        </div>
      </div>
    `}};ee([ht({attribute:!1})],ie.prototype,"scheduleData",void 0),ee([ht({attribute:!1})],ie.prototype,"domain",void 0),ee([ht({type:Boolean})],ie.prototype,"editable",void 0),ee([ht({attribute:!1})],ie.prototype,"translations",void 0),ee([pt()],ie.prototype,"_swipingGroupNo",void 0),ee([pt()],ie.prototype,"_swipeX",void 0),ie=ee([Pt("hmip-device-schedule-list")],ie);const se=o`
  :host {
    display: block;
  }

  /* Dialog styles */
  ha-dialog {
    --ha-dialog-max-width: min(500px, 95vw);
    --ha-dialog-max-height: 90vh;
  }

  .editor-content {
    padding: 16px;
    display: flex;
    flex-direction: column;
    gap: 16px;
    overflow-y: auto;
    max-height: calc(90vh - 200px);
  }

  .form-group {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }

  .form-group label {
    font-weight: 500;
    font-size: 14px;
    color: var(--primary-text-color);
  }

  .form-group input[type="time"],
  .form-group input[type="text"],
  .form-group input[type="number"] {
    padding: 8px;
    border: 1px solid var(--divider-color);
    border-radius: 4px;
    background-color: var(--card-background-color);
    color: var(--primary-text-color);
    font-size: 14px;
  }

  ha-select {
    width: 100%;
  }

  ha-slider {
    width: 100%;
  }

  .slider-group {
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .slider-group ha-slider {
    flex: 1;
  }

  .slider-value {
    min-width: 40px;
    text-align: right;
    font-size: 14px;
    color: var(--primary-text-color);
  }

  .duration-row {
    display: flex;
    gap: 8px;
    align-items: center;
  }

  .duration-row input[type="number"] {
    flex: 1;
    padding: 8px;
    border: 1px solid var(--divider-color);
    border-radius: 4px;
    background-color: var(--card-background-color);
    color: var(--primary-text-color);
    font-size: 14px;
  }

  .duration-row ha-select {
    min-width: 80px;
    flex: 0 0 auto;
  }

  .weekday-checkboxes,
  .channel-checkboxes {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
  }

  .checkbox-label {
    display: flex;
    align-items: center;
    gap: 4px;
    cursor: pointer;
    font-size: 14px;
  }

  .validation-list {
    margin: 0;
    padding-left: 20px;
    list-style-type: disc;
  }

  .validation-list li {
    font-size: 13px;
    line-height: 1.6;
    margin: 4px 0;
  }

  .editor-footer {
    display: flex;
    justify-content: flex-end;
    gap: 12px;
    margin-top: 8px;
    padding-top: 16px;
    border-top: 1px solid var(--divider-color);
  }

  /* Mobile Optimization */
  @media (max-width: 768px) {
    ha-dialog {
      --ha-dialog-max-width: 100vw;
      --ha-dialog-max-height: 100vh;
    }

    .editor-content {
      max-height: calc(100vh - 150px);
    }

    .editor-footer {
      flex-direction: column-reverse;
      gap: 8px;
      position: sticky;
      bottom: 0;
      background-color: var(--card-background-color, #fff);
      margin: 0 -16px -16px;
      padding: 16px;
      z-index: 1;
    }

    .editor-footer ha-button {
      width: 100%;
    }

    .form-group input[type="time"],
    .form-group input[type="text"],
    .form-group input[type="number"] {
      font-size: 16px;
      min-height: 44px;
    }
  }
`;var ne=function(t,e,i,s){var n,a=arguments.length,o=a<3?e:null===s?s=Object.getOwnPropertyDescriptor(e,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)o=Reflect.decorate(t,e,i,s);else for(var r=t.length-1;r>=0;r--)(n=t[r])&&(o=(a<3?n(o):a>3?n(e,i,o):n(e,i))||o);return a>3&&o&&Object.defineProperty(e,i,o),o};let ae=class extends rt{constructor(){super(...arguments),this.open=!1,this.isNewEvent=!1,this._validationErrors=[]}static{this.styles=se}willUpdate(t){(t.has("open")||t.has("entry"))&&(this.open&&this.entry?(this._editingEntry={...this.entry},this._validationErrors=[]):this.open||(this._editingEntry=void 0,this._validationErrors=[]))}updated(t){super.updated(t),t.has("open")&&this.open&&!t.get("open")&&this.updateComplete.then(()=>{const t=this.shadowRoot?.querySelector("input[type='time'], ha-select, input");t?.focus()})}_updateEditingEntry(t){this._editingEntry&&(this._editingEntry={...this._editingEntry,...t},this._validationErrors=[],this.requestUpdate())}_handleClose(){this.dispatchEvent(new CustomEvent("editor-closed",{bubbles:!0,composed:!0}))}_handleSave(){if(!this._editingEntry||void 0===this.groupNo)return;const t=function(t,e){const i=[];(function(t){try{return function(t){const e=t.split(":");if(2!==e.length)throw new Error(`Invalid time format: ${t}`);const i=parseInt(e[0],10),s=parseInt(e[1],10);if(isNaN(i)||isNaN(s)||i<0||i>23||s<0||s>59)throw new Error(`Invalid time values: ${t}`)}(t),!0}catch{return!1}})(t.time)||i.push({field:"time",message:"Time must be in HH:MM format (00:00-23:59)"}),t.weekdays&&0!==t.weekdays.length||i.push({field:"weekdays",message:"At least one weekday must be selected"});const s=e?gt[e]:void 0;return"binary"===s?.levelType?0!==t.level&&1!==t.level&&i.push({field:"level",message:"Level must be 0 or 1 for switch"}):(t.level<0||t.level>1)&&i.push({field:"level",message:"Level must be between 0.0 and 1.0"}),"cover"===e&&null!==t.level_2&&(t.level_2<0||t.level_2>1)&&i.push({field:"level_2",message:"Slat position must be between 0.0 and 1.0"}),St(t.condition)&&(t.astro_offset_minutes<-720||t.astro_offset_minutes>720)&&i.push({field:"astro_offset_minutes",message:"Astro offset must be between -720 and 720 minutes"}),null===t.duration||Mt(t.duration)||i.push({field:"duration",message:"Invalid duration format"}),null===t.ramp_time||Mt(t.ramp_time)||i.push({field:"ramp_time",message:"Invalid ramp time format"}),i}(this._editingEntry,this.domain);t.length>0?this._validationErrors=t.map(t=>`${t.field}: ${t.message}`):this.dispatchEvent(new CustomEvent("save-event",{bubbles:!0,composed:!0,detail:{entry:{...this._editingEntry},groupNo:this.groupNo}}))}render(){return this.open&&this._editingEntry?V`
      <ha-dialog
        open
        @closed=${this._handleClose}
        .heading=${this.isNewEvent?this.translations.addEvent:this.translations.editEvent}
      >
        <div class="editor-content">
          ${this._renderTimeFields()} ${this._renderConditionFields()}
          ${this._renderWeekdayFields()} ${this._renderLevelFields()}
          ${this._renderDurationFields()} ${this._renderRampTimeFields()}
          ${this._renderChannelFields()} ${this._renderValidationErrors()}
          <div class="editor-footer">
            <ha-button @click=${this._handleClose}> ${this.translations.cancel} </ha-button>
            <ha-button @click=${this._handleSave}> ${this.translations.save} </ha-button>
          </div>
        </div>
      </ha-dialog>
    `:V``}_renderValidationErrors(){return V`
      <div aria-live="polite">
        ${this._validationErrors.length>0?V`
              <ha-alert alert-type="error">
                <ul class="validation-list">
                  ${this._validationErrors.map(t=>V`<li>${t}</li>`)}
                </ul>
              </ha-alert>
            `:""}
      </div>
    `}_renderTimeFields(){return this._editingEntry?V`
      <div class="form-group">
        <label>${this.translations.time}</label>
        <input
          type="time"
          .value=${this._editingEntry.time}
          @change=${t=>{this._updateEditingEntry({time:t.target.value})}}
        />
      </div>
    `:V``}_renderConditionFields(){if(!this._editingEntry)return V``;const t=St(this._editingEntry.condition);return V`
      <div class="form-group">
        <label>${this.translations.condition}</label>
        <ha-select
          .value=${this._editingEntry.condition}
          .options=${mt.map(t=>({value:t,label:this.translations.conditionLabels[t]||t}))}
          @selected=${t=>{t.stopPropagation();const e=t.detail.value,i={condition:e};"fixed_time"===e?(i.astro_type=null,i.astro_offset_minutes=0):null===this._editingEntry.astro_type&&(i.astro_type="sunrise"),this._updateEditingEntry(i)}}
          @closed=${t=>t.stopPropagation()}
        ></ha-select>
      </div>
      ${t?V`
            <div class="form-group">
              <label>${this.translations.astroSunrise}/${this.translations.astroSunset}</label>
              <ha-select
                .value=${this._editingEntry.astro_type||"sunrise"}
                .options=${[{value:"sunrise",label:this.translations.astroSunrise},{value:"sunset",label:this.translations.astroSunset}]}
                @selected=${t=>{t.stopPropagation(),this._updateEditingEntry({astro_type:t.detail.value})}}
                @closed=${t=>t.stopPropagation()}
              ></ha-select>
            </div>
            <div class="form-group">
              <label>${this.translations.astroOffset}</label>
              <input
                type="number"
                min="-720"
                max="720"
                .value=${String(this._editingEntry.astro_offset_minutes)}
                @input=${t=>{const e=parseInt(t.target.value,10);isNaN(e)||this._updateEditingEntry({astro_offset_minutes:e})}}
              />
            </div>
          `:""}
    `}_renderWeekdayFields(){return this._editingEntry?V`
      <div class="form-group">
        <label>${this.translations.weekdaysLabel}</label>
        <div class="weekday-checkboxes">
          ${ut.map(t=>{const e=this._editingEntry.weekdays.includes(t);return V`
              <label class="checkbox-label">
                <ha-checkbox
                  .checked=${e}
                  @change=${e=>{const i=e.target.checked,s=[...this._editingEntry.weekdays];if(i&&!s.includes(t))s.push(t);else if(!i){const e=s.indexOf(t);e>-1&&s.splice(e,1)}this._updateEditingEntry({weekdays:s})}}
                ></ha-checkbox>
                ${this.translations.weekdayShortLabels[t]}
              </label>
            `})}
        </div>
      </div>
    `:V``}_renderLevelFields(){if(!this._editingEntry)return V``;const t=this.domain?gt[this.domain]:void 0;return V`
      <div class="form-group">
        <label>${this.translations.stateLabel}</label>
        ${"binary"===t?.levelType?V`
              <ha-select
                .value=${String(this._editingEntry.level)}
                .options=${[{value:"0",label:this.translations.levelOff},{value:"1",label:this.translations.levelOn}]}
                @selected=${t=>{t.stopPropagation();const e=parseInt(t.detail.value,10);this._updateEditingEntry({level:e})}}
                @closed=${t=>t.stopPropagation()}
              ></ha-select>
            `:V`
              <div class="slider-group">
                <ha-slider
                  min="0"
                  max="100"
                  .value=${Math.round(100*this._editingEntry.level)}
                  @change=${t=>{const e=Number(t.target.value);this._updateEditingEntry({level:e/100})}}
                ></ha-slider>
                <span class="slider-value">${Math.round(100*this._editingEntry.level)}%</span>
              </div>
            `}
      </div>
      ${t?.hasLevel2?V`
            <div class="form-group">
              <label>${this.translations.slat}</label>
              <div class="slider-group">
                <ha-slider
                  min="0"
                  max="100"
                  .value=${Math.round(100*(this._editingEntry.level_2||0))}
                  @change=${t=>{const e=Number(t.target.value);this._updateEditingEntry({level_2:e/100})}}
                ></ha-slider>
                <span class="slider-value"
                  >${Math.round(100*(this._editingEntry.level_2||0))}%</span
                >
              </div>
            </div>
          `:""}
    `}_renderDurationFields(){if(!this._editingEntry)return V``;const t=this.domain?gt[this.domain]:void 0;if(t&&!t.hasDuration)return V``;const e=this._editingEntry.duration?Tt(this._editingEntry.duration):null,i=e?.value??0,s=e?.unit??"s";return V`
      <div class="form-group">
        <label>${this.translations.duration}</label>
        <div class="duration-row">
          <input
            type="number"
            min="0"
            .value=${String(i)}
            @input=${t=>{const e=parseFloat(t.target.value);!isNaN(e)&&e>0?this._updateEditingEntry({duration:Dt(e,s)}):this._updateEditingEntry({duration:null})}}
          />
          <ha-select
            .value=${s}
            .options=${vt.map(t=>({value:t,label:t}))}
            @selected=${t=>{t.stopPropagation(),i>0&&this._updateEditingEntry({duration:Dt(i,t.detail.value)})}}
            @closed=${t=>t.stopPropagation()}
          ></ha-select>
        </div>
      </div>
    `}_renderRampTimeFields(){if(!this._editingEntry)return V``;const t=this.domain?gt[this.domain]:void 0;if(t&&!t.hasRampTime)return V``;const e=this._editingEntry.ramp_time?Tt(this._editingEntry.ramp_time):null,i=e?.value??0,s=e?.unit??"s";return V`
      <div class="form-group">
        <label>${this.translations.rampTime}</label>
        <div class="duration-row">
          <input
            type="number"
            min="0"
            .value=${String(i)}
            @input=${t=>{const e=parseFloat(t.target.value);!isNaN(e)&&e>0?this._updateEditingEntry({ramp_time:Dt(e,s)}):this._updateEditingEntry({ramp_time:null})}}
          />
          <ha-select
            .value=${s}
            .options=${vt.map(t=>({value:t,label:t}))}
            @selected=${t=>{t.stopPropagation(),i>0&&this._updateEditingEntry({ramp_time:Dt(i,t.detail.value)})}}
            @closed=${t=>t.stopPropagation()}
          ></ha-select>
        </div>
      </div>
    `}_renderChannelFields(){return this._editingEntry&&this.availableTargetChannels&&Object.keys(this.availableTargetChannels).length>0?V`
        <div class="form-group">
          <label>${this.translations.channels}</label>
          <div class="channel-checkboxes">
            ${Object.entries(this.availableTargetChannels).map(([t,e])=>{const i=this._editingEntry.target_channels.includes(t);return V`
                <label class="checkbox-label">
                  <ha-checkbox
                    .checked=${i}
                    @change=${e=>{const i=e.target.checked,s=[...this._editingEntry.target_channels];if(i&&!s.includes(t))s.push(t);else if(!i){const e=s.indexOf(t);e>-1&&s.splice(e,1)}this._updateEditingEntry({target_channels:s})}}
                  ></ha-checkbox>
                  ${e.name||t}
                </label>
              `})}
          </div>
        </div>
      `:V``}};ne([ht({type:Boolean})],ae.prototype,"open",void 0),ne([ht({attribute:!1})],ae.prototype,"entry",void 0),ne([ht()],ae.prototype,"groupNo",void 0),ne([ht({type:Boolean})],ae.prototype,"isNewEvent",void 0),ne([ht({attribute:!1})],ae.prototype,"domain",void 0),ne([ht({attribute:!1})],ae.prototype,"availableTargetChannels",void 0),ne([ht({attribute:!1})],ae.prototype,"translations",void 0),ne([pt()],ae.prototype,"_editingEntry",void 0),ne([pt()],ae.prototype,"_validationErrors",void 0),ae=ne([Pt("hmip-device-schedule-editor")],ae);const oe={en:{weekdays:{short:{monday:"Mo",tuesday:"Tu",wednesday:"We",thursday:"Th",friday:"Fr",saturday:"Sa",sunday:"Su"},long:{monday:"Monday",tuesday:"Tuesday",wednesday:"Wednesday",thursday:"Thursday",friday:"Friday",saturday:"Saturday",sunday:"Sunday"}},domains:{switch:"Switch",light:"Light",cover:"Cover",valve:"Valve"},conditions:{fixed_time:"Fixed Time",astro:"Astro",fixed_if_before_astro:"Fixed if before Astro",astro_if_before_fixed:"Astro if before Fixed",fixed_if_after_astro:"Fixed if after Astro",astro_if_after_fixed:"Astro if after Fixed",earliest:"Earliest",latest:"Latest"},ui:{schedule:"Schedule",loading:"Loading schedule data...",entityNotFound:"Entity {entity} not found",clickToEdit:"Click on a day to edit its schedule",edit:"Edit {weekday}",cancel:"Cancel",save:"Save",addTimeBlock:"+ Add Time Block",copySchedule:"Copy schedule",pasteSchedule:"Paste schedule",undo:"Undo",redo:"Redo",undoShortcut:"Undo (Ctrl+Z)",redoShortcut:"Redo (Ctrl+Y)",toggleCompactView:"Compact view",toggleFullView:"Full view",exportSchedule:"Export",importSchedule:"Import",exportTooltip:"Export schedule to JSON file",importTooltip:"Import schedule from JSON file",exportSuccess:"Schedule exported successfully",importSuccess:"Schedule imported successfully",unsavedChanges:"Unsaved changes",saveAll:"Save all",discard:"Discard",enableDragDrop:"Enable drag & drop mode",disableDragDrop:"Disable drag & drop mode",confirmDiscardChanges:"You have unsaved changes. Do you want to discard them?",close:"Close",level:"Level",levelOn:"On",levelOff:"Off",slat:"Slat Position",addEvent:"Add Event",editEvent:"Edit Event",deleteEvent:"Delete Event",time:"Time",duration:"Duration",rampTime:"Ramp Time",state:"State",weekdays:"Weekdays",channels:"Target Channels",condition:"Condition",astroSunrise:"Sunrise",astroSunset:"Sunset",astroOffset:"Astro Offset (min)",or:"or",ifBefore:"if before",ifAfter:"if after",maxEntriesReached:"Maximum number of entries reached ({max})",confirmDelete:"Are you sure you want to delete this event?"},errors:{failedToChangeProfile:"Failed to change profile: {error}",failedToSaveSchedule:"Failed to save schedule: {error}",failedToPasteSchedule:"Failed to paste schedule: {error}",invalidSchedule:"Invalid schedule: {error}",failedToExport:"Failed to export schedule: {error}",failedToImport:"Failed to import schedule: {error}",invalidImportFile:"Invalid file format. Please select a JSON file.",invalidImportFormat:"Invalid JSON format in file.",invalidImportData:"Invalid schedule data: {error}",incompatibleEntity:"Entity {entity} is not a compatible schedule entity (requires schedule_type 'default')",insufficientPermissions:"You don't have permission to perform this action."},warnings:{title:"Validation Warnings",noWarnings:"No issues detected"}},de:{weekdays:{short:{monday:"Mo",tuesday:"Di",wednesday:"Mi",thursday:"Do",friday:"Fr",saturday:"Sa",sunday:"So"},long:{monday:"Montag",tuesday:"Dienstag",wednesday:"Mittwoch",thursday:"Donnerstag",friday:"Freitag",saturday:"Samstag",sunday:"Sonntag"}},domains:{switch:"Schalter",light:"Licht",cover:"Rollladen",valve:"Ventil"},conditions:{fixed_time:"Feste Zeit",astro:"Astro",fixed_if_before_astro:"Fest wenn vor Astro",astro_if_before_fixed:"Astro wenn vor Fest",fixed_if_after_astro:"Fest wenn nach Astro",astro_if_after_fixed:"Astro wenn nach Fest",earliest:"Frühester",latest:"Spätester"},ui:{schedule:"Zeitplan",loading:"Zeitplandaten werden geladen...",entityNotFound:"Entität {entity} nicht gefunden",clickToEdit:"Klicken Sie auf einen Tag, um den Zeitplan zu bearbeiten",edit:"{weekday} bearbeiten",cancel:"Abbrechen",save:"Speichern",addTimeBlock:"+ Zeitblock hinzufügen",copySchedule:"Zeitplan kopieren",pasteSchedule:"Zeitplan einfügen",undo:"Rückgängig",redo:"Wiederholen",undoShortcut:"Rückgängig (Strg+Z)",redoShortcut:"Wiederholen (Strg+Y)",toggleCompactView:"Kompaktansicht",toggleFullView:"Vollansicht",exportSchedule:"Exportieren",importSchedule:"Importieren",exportTooltip:"Zeitplan als JSON-Datei exportieren",importTooltip:"Zeitplan aus JSON-Datei importieren",exportSuccess:"Zeitplan erfolgreich exportiert",importSuccess:"Zeitplan erfolgreich importiert",unsavedChanges:"Ungespeicherte Änderungen",saveAll:"Alle speichern",discard:"Verwerfen",enableDragDrop:"Drag & Drop Modus aktivieren",disableDragDrop:"Drag & Drop Modus deaktivieren",confirmDiscardChanges:"Sie haben ungespeicherte Änderungen. Möchten Sie diese verwerfen?",close:"Schließen",level:"Stufe",levelOn:"Ein",levelOff:"Aus",slat:"Lamellenposition",addEvent:"Ereignis hinzufügen",editEvent:"Ereignis bearbeiten",deleteEvent:"Ereignis löschen",time:"Zeit",duration:"Dauer",rampTime:"Rampenzeit",state:"Zustand",weekdays:"Wochentage",channels:"Zielkanäle",condition:"Bedingung",astroSunrise:"Sonnenaufgang",astroSunset:"Sonnenuntergang",astroOffset:"Astro-Offset (Min.)",or:"oder",ifBefore:"wenn vor",ifAfter:"wenn nach",maxEntriesReached:"Maximale Anzahl an Einträgen erreicht ({max})",confirmDelete:"Möchten Sie dieses Ereignis wirklich löschen?"},errors:{failedToChangeProfile:"Fehler beim Wechseln des Profils: {error}",failedToSaveSchedule:"Fehler beim Speichern des Zeitplans: {error}",failedToPasteSchedule:"Fehler beim Einfügen des Zeitplans: {error}",invalidSchedule:"Ungültiger Zeitplan: {error}",failedToExport:"Fehler beim Exportieren des Zeitplans: {error}",failedToImport:"Fehler beim Importieren des Zeitplans: {error}",invalidImportFile:"Ungültiges Dateiformat. Bitte wählen Sie eine JSON-Datei.",invalidImportFormat:"Ungültiges JSON-Format in der Datei.",invalidImportData:"Ungültige Zeitplandaten: {error}",incompatibleEntity:"Entität {entity} ist keine kompatible Zeitplan-Entität (erfordert schedule_type 'default')",insufficientPermissions:"Sie haben keine Berechtigung für diese Aktion."},warnings:{title:"Validierungswarnungen",noWarnings:"Keine Probleme erkannt"}}};function re(t){const e=t.toLowerCase().split("-")[0];return oe[e]||oe.en}function le(t,e){let i=t;for(const[t,s]of Object.entries(e))i=i.replace(`{${t}}`,s);return i}class de extends rt{constructor(){super(...arguments),this._isLoading=!1,this._translations=re("en"),this._showEditor=!1,this._isNewEvent=!1,this._alertType="error"}get _isEditable(){return this._config?.editable??!0}setConfig(t){const e=[],i=t=>{if(!t)return;const i=t.trim();i&&(e.includes(i)||e.push(i))};if(i(t.entity),Array.isArray(t.entities)&&t.entities.forEach(t=>i(t)),0===e.length)throw new Error("You need to define at least one entity");e.sort((t,e)=>t.localeCompare(e));const s=this._activeEntityId,n=e[0],a=s&&e.includes(s)?s:n;this._config={editable:!0,hour_format:"24",...t,entity:n,entities:[...e]},this._activeEntityId=a,this._editingEntry=void 0,this._editingGroupNo=void 0,this._showEditor=!1,this._updateLanguage()}_updateLanguage(){let t="en";this._config?.language?t=this._config.language:this.hass?.language?t=this.hass.language:this.hass?.locale?.language&&(t=this.hass.locale.language),this._translations=re(t)}shouldUpdate(t){if(t.has("hass")){const e=t.get("hass");if(this.hass&&e){if(this.hass.language===e.language&&this.hass.locale?.language===e.locale?.language||this._updateLanguage(),this._activeEntityId&&!this._isLoading){const t=e.states?.[this._activeEntityId],i=this.hass.states?.[this._activeEntityId];t!==i&&this._updateScheduleData()}}else this.hass&&!e&&(this._updateLanguage(),this._updateScheduleData())}return t.has("_activeEntityId")&&this._updateScheduleData(),!0}_isValidScheduleEntity(t){const e=this.hass?.states?.[t];return!!e&&Ot(e.attributes)}_updateScheduleData(){if(!this._activeEntityId||!this.hass?.states)return this._scheduleData=void 0,this._domain=void 0,this._availableTargetChannels=void 0,void(this._maxEntries=void 0);const t=this.hass.states[this._activeEntityId];if(!t)return this._scheduleData=void 0,this._domain=void 0,this._availableTargetChannels=void 0,void(this._maxEntries=void 0);const e=t.attributes;if(!Ot(e))return this._scheduleData=void 0,this._domain=void 0,this._availableTargetChannels=void 0,void(this._maxEntries=void 0);this._scheduleData=e.schedule_data?.entries,this._availableTargetChannels=e.available_target_channels,this._maxEntries=e.max_entries,this._domain=e.schedule_domain?e.schedule_domain:this._config?.schedule_domain?this._config.schedule_domain:void 0}_getEntityName(t){const e=this.hass?.states?.[t];return e?.attributes?.friendly_name||t}_handleEntityChange(t){t.stopPropagation(),this._activeEntityId=t.detail.value,this._closeEditor()}_getDeviceAddress(t){const e=this.hass?.states?.[t];if(e)return function(t){if(!t)return;const e=t.split(":");return 2===e.length?e[0]:void 0}(e.attributes.address)}_requireDeviceAddress(t){const e=this._getDeviceAddress(t);if(!e)throw new Error(`Cannot determine device address for entity ${t}`);return e}_requireConfigEntryId(t){const e=this.hass?.states?.[t],i=e?.attributes?.config_entry_id;if(!i)throw new Error(`Cannot resolve config_entry_id for entity ${t}. Ensure the entity has a valid config_entry_id attribute.`);return i}_showAlert(t,e="error"){this._alertMessage=t,this._alertType=e}_dismissAlert(){this._alertMessage=void 0}_onAddEvent(){if(this._maxEntries&&this._scheduleData&&Object.keys(this._scheduleData).length>=this._maxEntries)return void this._showAlert(le(this._translations.ui.maxEntriesReached,{max:String(this._maxEntries)}),"warning");const t=function(t){const e={weekdays:[],time:"00:00",condition:"fixed_time",astro_type:null,astro_offset_minutes:0,target_channels:[],level:0,level_2:null,duration:null,ramp_time:null};return"cover"===t&&(e.level_2=0),e}(this._domain);if(this._availableTargetChannels){const e=Object.keys(this._availableTargetChannels)[0];e&&(t.target_channels=[e])}const e=this._scheduleData?Object.keys(this._scheduleData).map(t=>parseInt(t,10)):[],i=e.length>0?Math.max(...e):0;this._editingGroupNo=String(i+1),this._editingEntry={...t},this._isNewEvent=!0,this._showEditor=!0}_onEditEvent(t){const e=t.detail.entry;this._editingGroupNo=e.groupNo,this._editingEntry={...e},this._isNewEvent=!1,this._showEditor=!0}_onDeleteEvent(t){if(!confirm(this._translations.ui.confirmDelete||"Delete this event?"))return;const e={...this._scheduleData};delete e[t.detail.entry.groupNo],this._saveSchedule(e)}_onSaveEvent(t){const{entry:e,groupNo:i}=t.detail,s={...this._scheduleData,[i]:e};this._saveSchedule(s),this._closeEditor()}_onEditorClosed(){this._closeEditor()}_closeEditor(){this._showEditor=!1,this._editingEntry=void 0,this._editingGroupNo=void 0,this._isNewEvent=!1}async _saveSchedule(t){if(!this._activeEntityId||!this.hass)return;const e=this._activeEntityId;this._startLoading();try{const i=this._requireConfigEntryId(e),s=this._requireDeviceAddress(e);await async function(t,e,i,s){return t.callWS({type:"homematicip_local/config/set_device_schedule",entry_id:e,device_address:i,schedule_data:s})}(this.hass,i,s,{entries:Lt(t)}),this._scheduleData=t,this._needsManualReload(e)&&this._scheduleReloadDeviceConfig(e)}catch(t){const e=String(t);e.includes("unauthorized")||e.includes("Unauthorized")?this._showAlert(this._translations.errors.insufficientPermissions):this._showAlert(le(this._translations.errors.failedToSaveSchedule,{error:e}))}finally{this._stopLoading()}}_startLoading(){this._isLoading=!0,this._loadingTimeoutId=window.setTimeout(()=>{this._isLoading=!1},1e4)}_stopLoading(){this._isLoading=!1,void 0!==this._loadingTimeoutId&&(clearTimeout(this._loadingTimeoutId),this._loadingTimeoutId=void 0)}_exportSchedule(){if(this._scheduleData&&this._activeEntityId)try{const t=this._getEntityName(this._activeEntityId),e={version:"2.0",entity:this._activeEntityId,schedule_domain:this._domain,exportDate:(new Date).toISOString(),schedule:this._scheduleData},i=new Blob([JSON.stringify(e,null,2)],{type:"application/json"}),s=URL.createObjectURL(i),n=document.createElement("a");n.href=s;const a=(new Date).toISOString().split("T")[0];n.download=`schedule-${t.replace(/[^a-zA-Z0-9]/g,"_")}-${a}.json`,document.body.appendChild(n),n.click(),document.body.removeChild(n),URL.revokeObjectURL(s)}catch(t){this._showAlert(le(this._translations.errors.failedToExport,{error:String(t)}))}}_importSchedule(){if(!this._isEditable)return;const t=document.createElement("input");t.type="file",t.accept=".json",t.onchange=async t=>{const e=t.target.files?.[0];if(e)try{const t=await e.text(),i=JSON.parse(t);if(!i.schedule||"object"!=typeof i.schedule)throw new Error(this._translations.errors.invalidImportData);if(i.schedule_domain&&i.schedule_domain!==this._domain&&!confirm(`Warning: The imported schedule is for a ${i.schedule_domain} device, but the current entity is a ${this._domain} device. Continue anyway?`))return;await this._saveSchedule(i.schedule)}catch(t){t instanceof SyntaxError?this._showAlert(this._translations.errors.invalidImportFormat):this._showAlert(le(this._translations.errors.failedToImport,{error:String(t)}))}},t.click()}_needsManualReload(t){if(!t||!this.hass)return!1;const e=this.hass.states[t];if(!e?.attributes?.interface_id)return!1;const i=e.attributes.interface_id;return i.endsWith("BidCos-RF")||i.endsWith("BidCos-Wired")||i.endsWith("VirtualDevices")}_scheduleReloadDeviceConfig(t){if(!this.hass)return;const e=this._getDeviceAddress(t);if(!e)return;const i=this.hass.states[t],s=i?.attributes?.config_entry_id;s&&setTimeout(async()=>{try{await async function(t,e,i){return t.callWS({type:"homematicip_local/config/reload_device_config",entry_id:e,device_address:i})}(this.hass,s,e)}catch{}},5e3)}_buildListTranslations(){const t=this._translations;return{weekdayShortLabels:{MONDAY:t.weekdays.short.monday,TUESDAY:t.weekdays.short.tuesday,WEDNESDAY:t.weekdays.short.wednesday,THURSDAY:t.weekdays.short.thursday,FRIDAY:t.weekdays.short.friday,SATURDAY:t.weekdays.short.saturday,SUNDAY:t.weekdays.short.sunday},condition:t.ui.condition,time:t.ui.time,weekdays:t.ui.weekdays,duration:t.ui.duration,state:t.ui.state,addEvent:t.ui.addEvent,editEvent:t.ui.editEvent,deleteEvent:t.ui.deleteEvent,slat:t.ui.slat,noScheduleEvents:"No schedule events configured",loading:t.ui.loading,conditionLabels:t.conditions,levelOn:t.ui.levelOn,levelOff:t.ui.levelOff,conditionSummaryLabels:{sunrise:t.ui.astroSunrise,sunset:t.ui.astroSunset,or:t.ui.or,ifBefore:t.ui.ifBefore,ifAfter:t.ui.ifAfter}}}_buildEditorTranslations(){const t=this._translations;return{weekdayShortLabels:{MONDAY:t.weekdays.short.monday,TUESDAY:t.weekdays.short.tuesday,WEDNESDAY:t.weekdays.short.wednesday,THURSDAY:t.weekdays.short.thursday,FRIDAY:t.weekdays.short.friday,SATURDAY:t.weekdays.short.saturday,SUNDAY:t.weekdays.short.sunday},addEvent:t.ui.addEvent,editEvent:t.ui.editEvent,cancel:t.ui.cancel,save:t.ui.save,time:t.ui.time,condition:t.ui.condition,weekdaysLabel:t.ui.weekdays,stateLabel:t.ui.state,duration:t.ui.duration,rampTime:t.ui.rampTime,channels:t.ui.channels,levelOn:t.ui.levelOn,levelOff:t.ui.levelOff,slat:t.ui.slat,astroSunrise:t.ui.astroSunrise,astroSunset:t.ui.astroSunset,astroOffset:t.ui.astroOffset,confirmDelete:t.ui.confirmDelete,conditionLabels:t.conditions}}_renderEntitySelector(){if(!this._config?.entities||this._config.entities.length<=1)return V``;const t=this._config.entities.filter(t=>this._isValidScheduleEntity(t));return 0===t.length?V``:V`
      <ha-select
        class="entity-selector-dropdown"
        .value=${this._activeEntityId||""}
        .options=${t.map(t=>({value:t,label:this._getEntityName(t)}))}
        @selected=${this._handleEntityChange}
        @closed=${t=>t.stopPropagation()}
      ></ha-select>
    `}_renderHeaderControls(){return V`
      <div class="header-controls">
        ${this._config?.entities&&this._config.entities.length>1?this._renderEntitySelector():""}
        <ha-icon-button
          .path=${"M5,20H19V18H5M19,9H15V3H9V9H5L12,16L19,9Z"}
          @click=${this._exportSchedule}
          .label=${this._translations.ui.exportTooltip}
          .disabled=${!this._scheduleData}
        ></ha-icon-button>
        ${this._isEditable?V`<ha-icon-button
              .path=${"M9,16V10H5L12,3L19,10H15V16H9M5,20V18H19V20H5Z"}
              @click=${this._importSchedule}
              .label=${this._translations.ui.importTooltip}
            ></ha-icon-button>`:""}
      </div>
    `}render(){if(!this._config||!this.hass)return V``;const t=this._activeEntityId?this.hass.states?.[this._activeEntityId]:void 0,e=this._config.name||t?.attributes?.friendly_name||this._translations.ui.schedule;return t?this._isValidScheduleEntity(this._activeEntityId)?V`
      <ha-card>
        <div class="card-header">
          <div class="header-left">
            <div class="card-title">${e}</div>
          </div>
        </div>
        ${this._renderHeaderControls()}
        <div class="card-content">
          ${this._alertMessage?V`<ha-alert
                .alertType=${this._alertType}
                dismissable
                @alert-dismissed-clicked=${this._dismissAlert}
                >${this._alertMessage}</ha-alert
              >`:""}
          ${this._scheduleData?V`
                <hmip-device-schedule-list
                  .scheduleData=${this._scheduleData}
                  .domain=${this._domain}
                  .editable=${this._isEditable}
                  .translations=${this._buildListTranslations()}
                  @add-event=${this._onAddEvent}
                  @edit-event=${this._onEditEvent}
                  @delete-event=${this._onDeleteEvent}
                ></hmip-device-schedule-list>
              `:V`<div class="loading">${this._translations.ui.loading}</div>`}
          ${this._isEditable?V`<div class="hint">${this._translations.ui.clickToEdit}</div>`:""}
        </div>
        ${this._isLoading?V`
              <div class="loading-overlay">
                <ha-circular-progress indeterminate></ha-circular-progress>
              </div>
            `:""}
      </ha-card>
      <hmip-device-schedule-editor
        .open=${this._showEditor}
        .entry=${this._editingEntry}
        .groupNo=${this._editingGroupNo}
        .isNewEvent=${this._isNewEvent}
        .domain=${this._domain}
        .availableTargetChannels=${this._availableTargetChannels}
        .translations=${this._buildEditorTranslations()}
        @save-event=${this._onSaveEvent}
        @editor-closed=${this._onEditorClosed}
      ></hmip-device-schedule-editor>
    `:V`
        <ha-card>
          <div class="card-header">
            <div class="header-left">
              <div class="card-title">${e}</div>
            </div>
          </div>
          ${this._renderHeaderControls()}
          <div class="card-content">
            <div class="error">
              ${le(this._translations.errors.incompatibleEntity,{entity:this._activeEntityId})}
            </div>
          </div>
        </ha-card>
      `:V`
        <ha-card>
          <div class="card-header">
            <div class="header-left">
              <div class="card-title">${e}</div>
            </div>
          </div>
          <div class="card-content">
            <div class="error">
              ${le(this._translations.ui.entityNotFound,{entity:this._activeEntityId||this._translations.ui.schedule})}
            </div>
          </div>
        </ha-card>
      `}static get styles(){return o`
      :host {
        display: block;
      }

      ha-card {
        padding: 16px;
        position: relative;
      }

      .card-header {
        display: block;
        margin-bottom: 8px;
      }

      .header-left {
        display: flex;
        align-items: center;
        gap: 12px;
      }

      .card-title {
        font-size: 24px;
        font-weight: 400;
        color: var(--primary-text-color);
      }

      .header-controls {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        margin-bottom: 16px;
      }

      .entity-selector-dropdown {
        flex: 1;
        max-width: 300px;
      }

      ha-icon-button[disabled] {
        opacity: 0.5;
      }

      .card-content {
        position: relative;
      }

      .loading {
        padding: 20px;
        text-align: center;
        color: var(--secondary-text-color);
      }

      .hint {
        margin-top: 12px;
        text-align: center;
        font-size: 12px;
        color: var(--secondary-text-color);
      }

      .error {
        padding: 20px;
        text-align: center;
        color: var(--error-color, #e74c3c);
      }

      /* Loading Overlay */
      .loading-overlay {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: rgba(0, 0, 0, 0.5);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 1000;
        border-radius: 4px;
      }

      ha-circular-progress {
        color: var(--primary-color);
      }

      /* Mobile Optimization */
      @media (max-width: 768px) {
        ha-card {
          padding: 12px;
        }

        .card-header {
          margin-bottom: 12px;
        }

        .header-left {
          justify-content: center;
        }

        .card-title {
          font-size: 20px;
        }

        .header-controls {
          flex-wrap: wrap;
          justify-content: center;
        }

        .entity-selector-dropdown {
          max-width: none;
          flex: 1 1 100%;
        }
      }
    `}getCardSize(){return 4}static getConfigElement(){return document.createElement("homematicip-local-schedule-card-editor")}static getStubConfig(){return{entity:"",editable:!0,hour_format:"24"}}}t([ht({attribute:!1})],de.prototype,"hass",void 0),t([pt()],de.prototype,"_config",void 0),t([pt()],de.prototype,"_scheduleData",void 0),t([pt()],de.prototype,"_activeEntityId",void 0),t([pt()],de.prototype,"_domain",void 0),t([pt()],de.prototype,"_isLoading",void 0),t([pt()],de.prototype,"_translations",void 0),t([pt()],de.prototype,"_editingEntry",void 0),t([pt()],de.prototype,"_editingGroupNo",void 0),t([pt()],de.prototype,"_showEditor",void 0),t([pt()],de.prototype,"_isNewEvent",void 0),t([pt()],de.prototype,"_availableTargetChannels",void 0),t([pt()],de.prototype,"_maxEntries",void 0),t([pt()],de.prototype,"_alertMessage",void 0),t([pt()],de.prototype,"_alertType",void 0);const ce="homematicip-local-schedule-card";customElements.get(ce)||customElements.define(ce,de),window.customCards=window.customCards||[],window.customCards.some(t=>t.type===ce)||window.customCards.push({type:ce,name:"HomematicIP Local Scheduler Card",description:"A custom card for Homematic(IP) Local schedules (switch, valve, cover, light)"});export{de as HomematicScheduleCard};
